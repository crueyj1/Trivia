// Update to enhanced-game-logic.js to implement reduced round length

// Modify the questionsPerRound constant in the game state
let gameState = {
  // Basic game settings
  score: 0,
  currentDifficulty: DIFFICULTY.MEDIUM,
  currentQuestion: null,
  questionHistory: [],
  availableQuestions: [],
  gameStatus: GAME_STATUS.WELCOME,
  answerResult: null,
  
  // New features
  gameMode: GAME_MODE.KID,
  categoryType: CATEGORY_TYPE.FIELDING,
  gameType: GAME_TYPE.SINGLE,
  
  // Multiplayer specific
  players: [],
  currentPlayerIndex: 0,
  currentRound: 1,
  questionsPerRound: 5, // Changed from 10 to 5 as requested
  questionCount: 0,
  roundWinners: []
};

// Also update the resetGame function to ensure the new value is maintained
function resetGame() {
  // Preserve preferences
  const gameMode = gameState.gameMode;
  const categoryType = gameState.categoryType;
  
  gameState = {
    // Basic game settings
    score: 0,
    currentDifficulty: DIFFICULTY.MEDIUM,
    currentQuestion: null,
    questionHistory: [],
    availableQuestions: [],
    gameStatus: GAME_STATUS.WELCOME,
    answerResult: null,
    
    // Preserved preferences
    gameMode: gameMode || GAME_MODE.KID,
    categoryType: categoryType || CATEGORY_TYPE.FIELDING,
    gameType: GAME_TYPE.SINGLE,
    
    // Multiplayer specific
    players: [],
    currentPlayerIndex: 0,
    currentRound: 1,
    questionsPerRound: 5, // Changed from 10 to 5 as requested
    questionCount: 0,
    roundWinners: []
  };
  
  // Save preferences
  localStorage.setItem('skibitySigna_gameMode', gameState.gameMode);
  localStorage.setItem('skibitySigna_categoryType', gameState.categoryType);
  
  return gameState;
}
