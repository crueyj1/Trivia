// Baseball Trivia Game - Scenario Database

// This file contains the collection of baseball scenarios and questions
// organized by difficulty level

const scenarios = {
  easy: [
    {
      id: "e1",
      scenario: "It's the top of the 3rd inning, no outs, bases empty. A routine ground ball is hit to the second baseman.",
      question: "What is the correct play for the second baseman?",
      options: [
        "Throw to third base",
        "Throw to first base for the out",
        "Hold the ball",
        "Throw to second base"
      ],
      correctAnswer: 1, // B
      explanation: "With no runners on base, the second baseman should make the routine play to first base for the sure out. This is the fundamental play in this situation.",
      difficulty: "easy"
    },
    {
      id: "e2",
      scenario: "It's the bottom of the 5th inning, 1 out, runner on first base. A fly ball is hit to right field.",
      question: "What should the right fielder do after catching the ball?",
      options: [
        "Immediately throw to second base",
        "Throw to first base to try for a double play",
        "Throw to the cutoff man",
        "Hold the ball"
      ],
      correctAnswer: 2, // C
      explanation: "With a runner on first and one out, the right fielder should throw to the cutoff man after catching the fly ball. This allows the infield to direct the throw where needed if the runner attempts to advance.",
      difficulty: "easy"
    },
    {
      id: "e3",
      scenario: "It's the top of the 2nd inning, 2 outs, runner on second base. A ground ball is hit directly to the shortstop.",
      question: "What is the best play for the shortstop?",
      options: [
        "Throw to third to try for the lead runner",
        "Throw to first for the sure out to end the inning",
        "Fake to first, then try to pick off the runner at second",
        "Hold the ball to prevent an error"
      ],
      correctAnswer: 1, // B
      explanation: "With two outs, the priority is getting the third out to end the inning. The shortstop should make the sure play to first base rather than risk a more difficult play at third base.",
      difficulty: "easy"
    },
    {
      id: "e4",
      scenario: "It's the bottom of the 4th inning, no outs, runner on first. The batter bunts down the third base line.",
      question: "What should the third baseman do?",
      options: [
        "Field the ball and throw to first for the out",
        "Let the pitcher field the ball",
        "Field the ball and throw to second for the force out",
        "Field the ball and tag the runner going to second"
      ],
      correctAnswer: 2, // C
      explanation: "With a runner on first and no outs, on a bunt down the third base line, the third baseman should field the ball and throw to second base for the force out. This removes the lead runner and is the higher-value out in this situation.",
      difficulty: "easy"
    },
    {
      id: "e5",
      scenario: "It's the top of the 6th inning, 1 out, bases empty. A pop fly is hit in the infield between the pitcher and first baseman.",
      question: "Who should call for and catch this ball?",
      options: [
        "The pitcher",
        "The first baseman",
        "The second baseman",
        "The catcher"
      ],
      correctAnswer: 1, // B
      explanation: "On an infield pop fly, the first baseman typically has priority over the pitcher. Infielders generally have priority over pitchers on pop flies because they have better angles and more experience catching pop-ups.",
      difficulty: "easy"
    }
  ],
  
  medium: [
    {
      id: "m1",
      scenario: "It's the bottom of the 7th inning, 1 out, runners on first and second. A sharp ground ball is hit to the shortstop's left.",
      question: "What is the best decision for the shortstop in this situation?",
      options: [
        "Dive for the ball and try to stop it",
        "Throw to third for the force out",
        "Throw to second to start a double play",
        "Throw to first for the sure out"
      ],
      correctAnswer: 2, // C
      explanation: "With runners on first and second and one out, the shortstop should try to start a double play by throwing to second base. This gives the defense a chance to get two outs, and at minimum should get the force at second. The situation (7th inning) makes getting outs a priority over preventing a single runner from advancing.",
      difficulty: "medium"
    },
    {
      id: "m2",
      scenario: "It's the top of the 8th inning, no outs, runner on first. Your team is ahead by one run. A bunt is laid down the first base line.",
      question: "What should the first baseman do?",
      options: [
        "Field the ball and tag the batter-runner",
        "Let the pitcher field the ball",
        "Field the ball and throw to first",
        "Field the ball and throw to second for the lead runner"
      ],
      correctAnswer: 3, // D
      explanation: "In a close game (ahead by one run) in the late innings (8th) with no outs, getting the lead runner is crucial. The first baseman should field the bunt and throw to second base to get the force out on the lead runner, preventing a runner from moving into scoring position.",
      difficulty: "medium"
    },
    {
      id: "m3",
      scenario: "It's the bottom of the 5th inning, 1 out, runners on first and third. Your team is up by 2 runs. The batter hits a ground ball to the second baseman.",
      question: "What is the optimal play for the second baseman?",
      options: [
        "Throw home to prevent the run",
        "Throw to first for the sure out",
        "Throw to second to start a double play",
        "Check the runner at third, then throw to first"
      ],
      correctAnswer: 2, // C
      explanation: "With runners on first and third and one out, the priority should be to try for the double play by throwing to second base. Even if the double play isn't completed, getting the force at second removes a runner. With a 2-run lead in the 5th inning, trading a run for two outs is an acceptable outcome.",
      difficulty: "medium"
    },
    {
      id: "m4",
      scenario: "It's the top of the 9th inning, 2 outs, runner on second. Your team is ahead by one run. A line drive is hit to right-center field.",
      question: "As the center fielder, what should you do if you can't catch the ball on the fly?",
      options: [
        "Dive for the ball to try to make the catch",
        "Play it on a hop and throw home immediately",
        "Play it on a hop and throw to the cutoff man",
        "Let the right fielder handle it"
      ],
      correctAnswer: 1, // B
      explanation: "In the 9th inning with 2 outs and a one-run lead, the runner on second will be trying to score on any hit. If you can't catch the ball, you should play it on a hop and throw home immediately to try to prevent the tying run from scoring. This is a situation where the run matters more than the batter advancing to second base.",
      difficulty: "medium"
    },
    {
      id: "m5",
      scenario: "It's the bottom of the 6th inning, 1 out, runners on first and second. Your team is down by 3 runs. A ground ball is hit to the third baseman.",
      question: "What should the third baseman do?",
      options: [
        "Step on third base and throw to first for a double play",
        "Throw to second to start a double play",
        "Throw to first for the sure out",
        "Tag the runner coming to third, then throw to first"
      ],
      correctAnswer: 1, // B
      explanation: "With runners on first and second and one out, the third baseman should throw to second base to start a potential double play. While stepping on third and throwing to first is also a double play possibility, the throw to second is typically easier and has a better chance of being completed successfully.",
      difficulty: "medium"
    }
  ],
  
  hard: [
    {
      id: "h1",
      scenario: "It's the bottom of the 9th inning, 2 outs, bases loaded. Your team is ahead by one run. A slow roller is hit toward third base.",
      question: "As the third baseman, what is the optimal play?",
      options: [
        "Charge the ball and throw to first",
        "Charge the ball and tag the runner going from second to third",
        "Let the shortstop handle it",
        "Charge and barehand the ball for a throw home"
      ],
      correctAnswer: 0, // A
      explanation: "In this critical situation (9th inning, 2 outs, bases loaded, 1-run lead), the third baseman should charge the ball and make the play to first base. With two outs, any force out ends the inning and preserves the win. The throw to first on a slow roller is the most direct and highest percentage play to get the force out.",
      difficulty: "hard"
    },
    {
      id: "h2",
      scenario: "It's the top of the 8th inning, no outs, runners on first and third. Your team is down by one run. The batter hits a fly ball to medium-deep right field.",
      question: "As the right fielder, what is the best decision after catching the ball?",
      options: [
        "Throw home immediately to prevent the run",
        "Throw to second base to keep the trail runner from advancing",
        "Throw to the cutoff man positioned for a throw home",
        "Throw to first base to try for a double play"
      ],
      correctAnswer: 2, // C
      explanation: "With runners on first and third and no outs in a one-run game, the right fielder should throw to the cutoff man after catching the fly ball. This gives the defense options: the cutoff man can redirect the throw home if the runner at third tags up, or hold the ball if the runner stays. Throwing directly home commits to one option and might allow the trail runner to advance to second (into scoring position).",
      difficulty: "hard"
    },
    {
      id: "h3",
      scenario: "It's the bottom of the 7th inning in a tie game, 1 out, runners on first and second. The batter hits a sharp one-hopper directly at the first baseman.",
      question: "What is the optimal play for the first baseman?",
      options: [
        "Step on first and throw to second for a double play",
        "Throw to second to start a 3-6-3 double play",
        "Tag the runner going to first, then throw to second",
        "Step on first for the sure out"
      ],
      correctAnswer: 1, // B
      explanation: "With runners on first and second and one out in a tie game, the first baseman should throw to second base to start a 3-6-3 double play (first to shortstop covering second, back to first). This gives the best chance to turn two outs. Stepping on first first would make the throw to second more difficult as the runner would no longer be forced to go to second base.",
      difficulty: "hard"
    },
    {
      id: "h4",
      scenario: "It's the top of the 6th inning, no outs, runner on second. Your team is up by one run. The batter attempts a sacrifice bunt down the third base line.",
      question: "As the third baseman, what is the correct play if the bunt is perfectly placed between the mound and third base?",
      options: [
        "Field the ball and throw to first for the sure out",
        "Let the pitcher field it",
        "Field the ball and fake to first, then try to catch the runner off second",
        "Field the ball and look the runner back to second before throwing to first"
      ],
      correctAnswer: 3, // D
      explanation: "With a runner on second and no outs in a one-run game, on a well-placed sacrifice bunt, the third baseman should field the ball and first look the runner back to second base before throwing to first. This prevents the runner from advancing to third too easily while still getting the out at first. The runner at third with one out is a significantly more dangerous situation than runner at second with one out.",
      difficulty: "hard"
    },
    {
      id: "h5",
      scenario: "It's the bottom of the 9th inning, 1 out, runners on first and third. Your team is ahead by one run. The batter hits a ground ball to the shortstop.",
      question: "What is the optimal defensive play for the shortstop?",
      options: [
        "Throw home to prevent the tying run",
        "Throw to third to catch the runner off the base",
        "Throw to second to start a double play",
        "Throw to first for the sure out"
      ],
      correctAnswer: 2, // C
      explanation: "In the 9th inning with a one-run lead, runners on first and third, and one out, the shortstop should attempt to start a double play by throwing to second base. Even if the double play isn't completed, getting the force at second is valuable. While preventing the tying run is important, getting two outs to end the game is the higher priority. If the double play is turned, the run doesn't score at all.",
      difficulty: "hard"
    }
  ]
};
