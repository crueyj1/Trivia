// Custom winner message implementation
// This file contains the code to implement the custom winner message for "Oh my Skibity Sigma"

// Update the getSeriesWinner function to include the custom message
function getSeriesWinner() {
  if (gameState.gameType !== GAME_TYPE.MULTIPLAYER) {
    return null;
  }
  
  // Find the player with the most series wins
  let mostWins = -1;
  let winnerIndex = -1;
  
  gameState.players.forEach((player, index) => {
    if (player.seriesWins > mostWins) {
      mostWins = player.seriesWins;
      winnerIndex = index;
    }
  });
  
  return winnerIndex >= 0 ? gameState.players[winnerIndex] : null;
}

// Create a function to generate the custom winner message
function getWinnerMessage(winner) {
  if (!winner) return "";
  
  return `${winner.name} dominated the show, and ${winner.name} is the official Skibity Rizler!!`;
}

// Update the renderSeriesResults function to include the custom winner message
function renderSeriesResults(container) {
  const seriesResults = document.createElement('div');
  seriesResults.className = 'series-results';
  
  // Get the series winner
  const seriesWinner = getSeriesWinner();
  
  // Generate the custom winner message
  const winnerMessage = seriesWinner ? getWinnerMessage(seriesWinner) : "The series ended in a tie!";
  
  // Create player results HTML
  let playersResultsHTML = '';
  gameState.players.forEach(player => {
    playersResultsHTML += `
      <div class="player-series-result ${player.id === (seriesWinner ? seriesWinner.id : -1) ? 'winner' : ''}">
        <div class="player-name">${player.name}</div>
        <div class="player-series-wins">Rounds Won: ${player.seriesWins}</div>
      </div>
    `;
  });
  
  seriesResults.innerHTML = `
    <h2>Series Results</h2>
    
    <div class="series-winner">
      <h3>${winnerMessage}</h3>
    </div>
    
    <div class="player-series-results">
      ${playersResultsHTML}
    </div>
    
    <div class="round-history">
      <h3>Round Winners:</h3>
      <ul>
        ${gameState.roundWinners.map((winnerID, index) => {
          const winner = gameState.players.find(player => player.id === winnerID);
          return `<li>Round ${index + 1}: ${winner ? winner.name : 'Tie'}</li>`;
        }).join('')}
      </ul>
    </div>
    
    <div class="series-buttons">
      <button class="btn new-series-btn">Play New Series</button>
      <button class="btn main-menu-btn">Main Menu</button>
    </div>
  `;
  
  // Add event listeners
  seriesResults.querySelector('.new-series-btn').addEventListener('click', function() {
    // Reset for a new series but keep the same players
    const playerNames = gameState.players.map(player => player.name);
    setupMultiplayerGame(playerNames);
    getNextQuestion();
    renderGameState();
  });
  
  seriesResults.querySelector('.main-menu-btn').addEventListener('click', function() {
    resetGame();
    renderGameState();
  });
  
  container.appendChild(seriesResults);
}

// Add CSS styles for the winner message to make it stand out
const winnerMessageStyles = `
/* Custom winner message styling */
.series-winner h3 {
  font-size: 1.8rem;
  color: var(--accent-color);
  text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3);
  margin-bottom: 15px;
  animation: pulse 1.5s infinite;
  font-family: 'Bangers', 'Comic Sans MS', cursive, sans-serif;
  letter-spacing: 1px;
}

@keyframes pulse {
  0% { transform: scale(1); }
  50% { transform: scale(1.05); }
  100% { transform: scale(1); }
}

/* Make the winner's name stand out */
.player-series-result.winner {
  background-color: rgba(255, 171, 0, 0.3);
  border: 3px solid var(--accent-color);
  transform: scale(1.05);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

/* Add confetti effect to the winner section */
.series-winner {
  background: linear-gradient(135deg, var(--primary-light), var(--accent-color));
  padding: 20px;
  border-radius: var(--border-radius);
  margin-bottom: 25px;
  position: relative;
  overflow: hidden;
}

.series-winner::before {
  content: '🎉';
  position: absolute;
  left: 10px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 2rem;
}

.series-winner::after {
  content: '🎉';
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 2rem;
}
`;

// Function to add the custom styles to the page
function addWinnerMessageStyles() {
  const styleElement = document.createElement('style');
  styleElement.textContent = winnerMessageStyles;
  document.head.appendChild(styleElement);
}

// Call this function when the page loads
document.addEventListener('DOMContentLoaded', function() {
  addWinnerMessageStyles();
});
