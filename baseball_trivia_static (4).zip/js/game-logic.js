// Game logic for Baseball Trivia Static Implementation

// Game state and constants
const GAME_STATUS = {
  WELCOME: 'welcome',
  PLAYING: 'playing',
  ANSWERED: 'answered',
  FINISHED: 'finished'
};

const DIFFICULTY = {
  EASY: 'easy',
  MEDIUM: 'medium',
  HARD: 'hard'
};

const DIFFICULTY_POINTS = {
  [DIFFICULTY.EASY]: 1,
  [DIFFICULTY.MEDIUM]: 2,
  [DIFFICULTY.HARD]: 3
};

// Game state object
let gameState = {
  score: 0,
  currentDifficulty: DIFFICULTY.MEDIUM,
  currentQuestion: null,
  questionHistory: [],
  availableScenarios: {
    [DIFFICULTY.EASY]: [],
    [DIFFICULTY.MEDIUM]: [],
    [DIFFICULTY.HARD]: []
  },
  gameStatus: GAME_STATUS.WELCOME,
  answerResult: null
};

// Initialize the game
function initializeGame() {
  resetGame();
  return gameState;
}

// Reset the game state
function resetGame() {
  gameState = {
    score: 0,
    currentDifficulty: DIFFICULTY.MEDIUM,
    currentQuestion: null,
    questionHistory: [],
    availableScenarios: {
      [DIFFICULTY.EASY]: [...scenarios.easy],
      [DIFFICULTY.MEDIUM]: [...scenarios.medium],
      [DIFFICULTY.HARD]: [...scenarios.hard]
    },
    gameStatus: GAME_STATUS.WELCOME,
    answerResult: null
  };
  
  // Shuffle the scenarios for each difficulty
  shuffleArray(gameState.availableScenarios[DIFFICULTY.EASY]);
  shuffleArray(gameState.availableScenarios[DIFFICULTY.MEDIUM]);
  shuffleArray(gameState.availableScenarios[DIFFICULTY.HARD]);
  
  return gameState;
}

// Set or change difficulty level
function setDifficulty(difficulty) {
  if (Object.values(DIFFICULTY).includes(difficulty)) {
    gameState.currentDifficulty = difficulty;
  }
  return gameState;
}

// Get the next scenario based on current difficulty
function getNextScenario() {
  const difficulty = gameState.currentDifficulty;
  
  // Check if we have scenarios available at the current difficulty
  if (gameState.availableScenarios[difficulty].length === 0) {
    // Refill the available scenarios if we've used them all
    const allScenariosOfDifficulty = gameState.questionHistory
      .filter(q => q.difficulty === difficulty)
      .map(q => ({ ...q }));
    
    if (allScenariosOfDifficulty.length > 0) {
      gameState.availableScenarios[difficulty] = [...allScenariosOfDifficulty];
      shuffleArray(gameState.availableScenarios[difficulty]);
    } else {
      // If we still have no scenarios, game is finished
      gameState.gameStatus = GAME_STATUS.FINISHED;
      return gameState;
    }
  }
  
  // Get the first scenario from the shuffled array
  const scenario = gameState.availableScenarios[difficulty][0];
  
  // Remove the selected scenario from available ones to avoid repetition
  gameState.availableScenarios[difficulty].shift();
  
  // Update game state
  gameState.currentQuestion = scenario;
  gameState.gameStatus = GAME_STATUS.PLAYING;
  gameState.answerResult = null;
  
  return gameState;
}

// Check answer and provide feedback
function checkAnswer(userAnswer) {
  if (!gameState.currentQuestion) {
    return gameState;
  }
  
  let isCorrect = false;
  let correctAnswerText = "";
  
  // Handle multiple choice answers (A, B, C, D format)
  if (gameState.currentQuestion.options) {
    // Convert letter answer to index (A->0, B->1, etc.)
    const letterToIndex = (letter) => letter.toUpperCase().charCodeAt(0) - 65;
    
    if (typeof userAnswer === 'string' && userAnswer.length === 1) {
      const answerIndex = letterToIndex(userAnswer);
      isCorrect = answerIndex === gameState.currentQuestion.correctAnswer;
      correctAnswerText = `${String.fromCharCode(65 + gameState.currentQuestion.correctAnswer)}) ${gameState.currentQuestion.options[gameState.currentQuestion.correctAnswer]}`;
    }
  } 
  
  // Calculate points awarded
  const pointsAwarded = isCorrect ? DIFFICULTY_POINTS[gameState.currentQuestion.difficulty] : 0;
  
  // Create answer result
  const answerResult = {
    isCorrect,
    correctAnswerText,
    explanation: gameState.currentQuestion.explanation,
    pointsAwarded
  };
  
  // Record question in history
  const answeredQuestion = {
    ...gameState.currentQuestion,
    userAnswer,
    isCorrect
  };
  
  // Update game state
  gameState.score += pointsAwarded;
  gameState.questionHistory.push(answeredQuestion);
  gameState.gameStatus = GAME_STATUS.ANSWERED;
  gameState.answerResult = answerResult;
  
  return gameState;
}

// Get performance feedback based on score
function getPerformanceFeedback() {
  const score = gameState.score;
  
  if (score === 0) {
    return "Keep practicing! Baseball fielding decisions require experience.";
  } else if (score < 5) {
    return "Good start! You're developing your baseball IQ.";
  } else if (score < 10) {
    return "Solid performance! You know your way around the diamond.";
  } else if (score < 15) {
    return "Excellent! You could be a field manager with that baseball knowledge.";
  } else {
    return "Outstanding! You have professional-level understanding of baseball fielding strategy!";
  }
}

// Utility function to shuffle an array (Fisher-Yates algorithm)
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}
