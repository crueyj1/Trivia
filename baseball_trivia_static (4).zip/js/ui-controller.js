// UI Controller for Baseball Trivia Static Implementation

// Wait for DOM to be fully loaded before initializing
document.addEventListener('DOMContentLoaded', function() {
  // Initialize the game
  initializeGame();
  
  // Render the initial game state
  renderGameState();
});

// Main function to render the game based on current state
function renderGameState() {
  const gameContainer = document.getElementById('game-container');
  
  // Clear the container
  gameContainer.innerHTML = '';
  
  // Render different views based on game status
  switch (gameState.gameStatus) {
    case GAME_STATUS.WELCOME:
      renderWelcomeScreen(gameContainer);
      break;
    case GAME_STATUS.PLAYING:
      renderScoreboard(gameContainer);
      renderScenario(gameContainer);
      break;
    case GAME_STATUS.ANSWERED:
      renderScoreboard(gameContainer);
      renderResult(gameContainer);
      break;
    case GAME_STATUS.FINISHED:
      renderScoreboard(gameContainer);
      renderGameOver(gameContainer);
      break;
  }
}

// Render the welcome screen
function renderWelcomeScreen(container) {
  const welcomeScreen = document.createElement('div');
  welcomeScreen.className = 'welcome-screen';
  
  welcomeScreen.innerHTML = `
    <h2>Welcome to Baseball Fielding Trivia!</h2>
    <div class="welcome-content">
      <p>
        Test your knowledge of infield and outfield decision-making in various baseball scenarios.
        Select a difficulty level and click Start to begin.
      </p>
      <p class="difficulty-info">
        Each correct answer earns you points based on difficulty:
        <span>Easy: 1 point | Medium: 2 points | Hard: 3 points</span>
      </p>
      
      <div class="difficulty-selector">
        <p>Select difficulty:</p>
        <div class="difficulty-buttons">
          <button class="btn difficulty-btn ${gameState.currentDifficulty === DIFFICULTY.EASY ? 'active' : ''}" 
                  data-difficulty="${DIFFICULTY.EASY}">Easy</button>
          <button class="btn difficulty-btn ${gameState.currentDifficulty === DIFFICULTY.MEDIUM ? 'active' : ''}" 
                  data-difficulty="${DIFFICULTY.MEDIUM}">Medium</button>
          <button class="btn difficulty-btn ${gameState.currentDifficulty === DIFFICULTY.HARD ? 'active' : ''}" 
                  data-difficulty="${DIFFICULTY.HARD}">Hard</button>
        </div>
      </div>
      
      <button class="btn start-btn">Start Game</button>
    </div>
  `;
  
  // Add event listeners
  welcomeScreen.querySelectorAll('.difficulty-btn').forEach(button => {
    button.addEventListener('click', function() {
      const difficulty = this.getAttribute('data-difficulty');
      setDifficulty(difficulty);
      
      // Update active button
      welcomeScreen.querySelectorAll('.difficulty-btn').forEach(btn => {
        btn.classList.remove('active');
      });
      this.classList.add('active');
    });
  });
  
  welcomeScreen.querySelector('.start-btn').addEventListener('click', function() {
    getNextScenario();
    renderGameState();
  });
  
  container.appendChild(welcomeScreen);
}

// Render the scoreboard
function renderScoreboard(container) {
  const scoreboard = document.createElement('div');
  scoreboard.className = 'scoreboard';
  
  scoreboard.innerHTML = `
    <div class="score">Score: ${gameState.score} points</div>
    <div class="difficulty-controls">
      <span>Difficulty:</span>
      <div class="difficulty-buttons">
        <button class="btn difficulty-btn small ${gameState.currentDifficulty === DIFFICULTY.EASY ? 'active' : ''}" 
                data-difficulty="${DIFFICULTY.EASY}">Easy</button>
        <button class="btn difficulty-btn small ${gameState.currentDifficulty === DIFFICULTY.MEDIUM ? 'active' : ''}" 
                data-difficulty="${DIFFICULTY.MEDIUM}">Medium</button>
        <button class="btn difficulty-btn small ${gameState.currentDifficulty === DIFFICULTY.HARD ? 'active' : ''}" 
                data-difficulty="${DIFFICULTY.HARD}">Hard</button>
      </div>
    </div>
  `;
  
  // Add event listeners
  scoreboard.querySelectorAll('.difficulty-btn').forEach(button => {
    button.addEventListener('click', function() {
      const difficulty = this.getAttribute('data-difficulty');
      setDifficulty(difficulty);
      
      // Update active button
      scoreboard.querySelectorAll('.difficulty-btn').forEach(btn => {
        btn.classList.remove('active');
      });
      this.classList.add('active');
      
      // Only update the scoreboard, don't change the current question
      renderGameState();
    });
  });
  
  container.appendChild(scoreboard);
}

// Render the current scenario and question
function renderScenario(container) {
  if (!gameState.currentQuestion) return;
  
  const scenarioDisplay = document.createElement('div');
  scenarioDisplay.className = 'scenario-display';
  
  scenarioDisplay.innerHTML = `
    <div class="scenario-box">
      <h3>SCENARIO:</h3>
      <p>${gameState.currentQuestion.scenario}</p>
    </div>
    
    <div class="question-box">
      <h3>QUESTION:</h3>
      <p>${gameState.currentQuestion.question}</p>
    </div>
    
    <div class="options-grid">
      ${gameState.currentQuestion.options.map((option, index) => `
        <button class="option-btn" data-answer="${String.fromCharCode(65 + index)}">
          <span class="option-letter">${String.fromCharCode(65 + index)})</span> 
          <span class="option-text">${option}</span>
        </button>
      `).join('')}
    </div>
  `;
  
  // Add event listeners
  scenarioDisplay.querySelectorAll('.option-btn').forEach(button => {
    button.addEventListener('click', function() {
      const answer = this.getAttribute('data-answer');
      checkAnswer(answer);
      renderGameState();
    });
  });
  
  container.appendChild(scenarioDisplay);
}

// Render the answer result
function renderResult(container) {
  if (!gameState.answerResult) return;
  
  const resultDisplay = document.createElement('div');
  resultDisplay.className = 'result-display';
  
  const resultClass = gameState.answerResult.isCorrect ? 'correct' : 'incorrect';
  
  resultDisplay.innerHTML = `
    <div class="result-box ${resultClass}">
      <h3>${gameState.answerResult.isCorrect ? 'Correct!' : 'Incorrect'}</h3>
      
      ${gameState.answerResult.isCorrect ? 
        `<p class="points-awarded">+${gameState.answerResult.pointsAwarded} points!</p>` : ''}
      
      <div class="correct-answer">
        <h4>Correct Answer:</h4>
        <p>${gameState.answerResult.correctAnswerText}</p>
      </div>
      
      <div class="explanation">
        <h4>Explanation:</h4>
        <p>${gameState.answerResult.explanation}</p>
      </div>
    </div>
    
    <button class="btn next-btn">Next Question</button>
  `;
  
  // Add event listener
  resultDisplay.querySelector('.next-btn').addEventListener('click', function() {
    getNextScenario();
    renderGameState();
  });
  
  container.appendChild(resultDisplay);
}

// Render the game over screen
function renderGameOver(container) {
  const gameOverScreen = document.createElement('div');
  gameOverScreen.className = 'game-over-screen';
  
  gameOverScreen.innerHTML = `
    <h2>Game Complete!</h2>
    <div class="final-score-box">
      <p class="final-score">Final Score: ${gameState.score} points</p>
      <p class="feedback">${getPerformanceFeedback()}</p>
    </div>
    <button class="btn play-again-btn">Play Again</button>
  `;
  
  // Add event listener
  gameOverScreen.querySelector('.play-again-btn').addEventListener('click', function() {
    resetGame();
    renderGameState();
  });
  
  container.appendChild(gameOverScreen);
}
