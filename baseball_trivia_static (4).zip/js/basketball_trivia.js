// Basketball Trivia Questions
// This file contains basketball trivia questions for the "Oh my Skibity Sigma" game

const basketballTrivia = {
  child: [
    {
      id: "bb_c1",
      question: "Which basketball player is known as 'King James'?",
      options: [
        "Michael Jordan",
        "LeBron James",
        "Stephen Curry",
        "Kevin Durant"
      ],
      correctAnswer: 1, // B - LeBron James
      explanation: "LeBron James is nicknamed 'King James' because of his amazing basketball skills and leadership on the court!",
      difficulty: "easy"
    },
    {
      id: "bb_c2",
      question: "How many players from each team are on the basketball court at the same time?",
      options: [
        "3 players",
        "5 players",
        "7 players",
        "9 players"
      ],
      correctAnswer: 1, // B - 5 players
      explanation: "In basketball, each team has 5 players on the court at the same time. That makes a total of 10 players on the court during a game.",
      difficulty: "easy"
    },
    {
      id: "bb_c3",
      question: "What team does Stephen Curry play for?",
      options: [
        "Los Angeles Lakers",
        "Brooklyn Nets",
        "Golden State Warriors",
        "Chicago Bulls"
      ],
      correctAnswer: 2, // C - Golden State Warriors
      explanation: "Stephen Curry plays for the Golden State Warriors. He's been with them his entire NBA career and has helped them win multiple championships!",
      difficulty: "easy"
    },
    {
      id: "bb_c4",
      question: "What color is a basketball usually?",
      options: [
        "Green",
        "Blue",
        "Orange",
        "Yellow"
      ],
      correctAnswer: 2, // C - Orange
      explanation: "Basketballs are usually orange with black lines. The bright orange color makes it easy for players to see the ball during fast-paced games!",
      difficulty: "easy"
    },
    {
      id: "bb_c5",
      question: "How many points is a regular basket worth in basketball?",
      options: [
        "1 point",
        "2 points",
        "3 points",
        "4 points"
      ],
      correctAnswer: 1, // B - 2 points
      explanation: "A regular basket in basketball is worth 2 points. Three-pointers are worth 3 points, and free throws are worth 1 point each.",
      difficulty: "easy"
    },
    {
      id: "bb_c6",
      question: "Which NBA player wears jersey number 30 and is famous for shooting three-pointers?",
      options: [
        "LeBron James",
        "Kevin Durant",
        "Stephen Curry",
        "Giannis Antetokounmpo"
      ],
      correctAnswer: 2, // C - Stephen Curry
      explanation: "Stephen Curry wears jersey number 30 and is known as one of the greatest three-point shooters in basketball history!",
      difficulty: "easy"
    },
    {
      id: "bb_c7",
      question: "What do you call it when a player jumps and puts the ball directly through the hoop from above?",
      options: [
        "A slam dunk",
        "A three-pointer",
        "A free throw",
        "A touchdown"
      ],
      correctAnswer: 0, // A - A slam dunk
      explanation: "That's called a slam dunk! It's when a player jumps high enough to push the ball down through the hoop with their hands.",
      difficulty: "easy"
    },
    {
      id: "bb_c8",
      question: "Which NBA player is known as 'The Greek Freak'?",
      options: [
        "Luka Dončić",
        "Nikola Jokić",
        "Giannis Antetokounmpo",
        "Joel Embiid"
      ],
      correctAnswer: 2, // C - Giannis Antetokounmpo
      explanation: "Giannis Antetokounmpo is known as 'The Greek Freak' because he's from Greece and has amazing athletic abilities that seem almost superhuman!",
      difficulty: "medium"
    },
    {
      id: "bb_c9",
      question: "What team won the most recent NBA Championship?",
      options: [
        "Boston Celtics",
        "Denver Nuggets",
        "Golden State Warriors",
        "Los Angeles Lakers"
      ],
      correctAnswer: 0, // A - Boston Celtics (as of 2024)
      explanation: "The Boston Celtics won the 2024 NBA Championship, defeating the Dallas Mavericks in the finals!",
      difficulty: "medium"
    },
    {
      id: "bb_c10",
      question: "What is the name of the NBA team in Toronto?",
      options: [
        "Toronto Wolves",
        "Toronto Raptors",
        "Toronto Maple Leafs",
        "Toronto Blue Jays"
      ],
      correctAnswer: 1, // B - Toronto Raptors
      explanation: "The Toronto Raptors are the only NBA team based in Canada. They won their first NBA Championship in 2019!",
      difficulty: "medium"
    },
    {
      id: "bb_c11",
      question: "Which player wears jersey number 23 for the Los Angeles Lakers?",
      options: [
        "Anthony Davis",
        "LeBron James",
        "Russell Westbrook",
        "Kevin Durant"
      ],
      correctAnswer: 0, // A - Anthony Davis
      explanation: "Anthony Davis wears jersey number 23 for the Los Angeles Lakers. LeBron James switched from 23 to number 6, and then back to 23 with the Lakers!",
      difficulty: "medium"
    },
    {
      id: "bb_c12",
      question: "How tall is the basketball hoop from the floor?",
      options: [
        "8 feet",
        "10 feet",
        "12 feet",
        "15 feet"
      ],
      correctAnswer: 1, // B - 10 feet
      explanation: "A basketball hoop is 10 feet (about 3 meters) high from the floor. This height is the same for kids, high school, college, and professional games!",
      difficulty: "medium"
    },
    {
      id: "bb_c13",
      question: "What does NBA stand for?",
      options: [
        "National Basketball Association",
        "National Basketball Alliance",
        "New Basketball Association",
        "National Ball Association"
      ],
      correctAnswer: 0, // A - National Basketball Association
      explanation: "NBA stands for National Basketball Association. It's the main professional basketball league in North America!",
      difficulty: "easy"
    },
    {
      id: "bb_c14",
      question: "Which player has won the most NBA MVP (Most Valuable Player) awards?",
      options: [
        "Michael Jordan",
        "LeBron James",
        "Kareem Abdul-Jabbar",
        "Kobe Bryant"
      ],
      correctAnswer: 2, // C - Kareem Abdul-Jabbar
      explanation: "Kareem Abdul-Jabbar has won the most NBA MVP awards with 6 total. Michael Jordan and Bill Russell each won 5, while LeBron James has won 4.",
      difficulty: "hard"
    },
    {
      id: "bb_c15",
      question: "What is the name of the trophy given to the NBA champions?",
      options: [
        "The Championship Cup",
        "The Golden Basketball",
        "The Larry O'Brien Trophy",
        "The NBA Cup"
      ],
      correctAnswer: 2, // C - The Larry O'Brien Trophy
      explanation: "The NBA champions receive the Larry O'Brien Championship Trophy, named after a former NBA commissioner who helped make the league more popular!",
      difficulty: "medium"
    }
  ],
  
  preteen: [
    {
      id: "bb_p1",
      question: "Which NBA player has the nickname 'The King' and wears #23?",
      options: [
        "Kevin Durant",
        "LeBron James",
        "Stephen Curry",
        "Giannis Antetokounmpo"
      ],
      correctAnswer: 1, // B - LeBron James
      explanation: "LeBron James is known as 'The King' or 'King James' and has worn #23 for most of his career (with a brief switch to #6 during his time with the Miami Heat and part of his Lakers tenure).",
      difficulty: "easy"
    },
    {
      id: "bb_p2",
      question: "Which player holds the NBA record for most points scored in a single game (100)?",
      options: [
        "Michael Jordan",
        "Kobe Bryant",
        "Wilt Chamberlain",
        "LeBron James"
      ],
      correctAnswer: 2, // C - Wilt Chamberlain
      explanation: "Wilt Chamberlain scored an incredible 100 points in a single game on March 2, 1962, when his Philadelphia Warriors defeated the New York Knicks. This record still stands today!",
      difficulty: "medium"
    },
    {
      id: "bb_p3",
      question: "What is Stephen Curry's jersey number?",
      options: [
        "23",
        "30",
        "35",
        "3"
      ],
      correctAnswer: 1, // B - 30
      explanation: "Stephen Curry wears jersey number 30 for the Golden State Warriors. He's worn this number throughout his NBA career and is famous for his amazing three-point shooting.",
      difficulty: "easy"
    },
    {
      id: "bb_p4",
      question: "Which NBA team has won the most championships in history?",
      options: [
        "Los Angeles Lakers",
        "Boston Celtics",
        "Chicago Bulls",
        "Golden State Warriors"
      ],
      correctAnswer: 1, // B - Boston Celtics
      explanation: "The Boston Celtics have won the most NBA championships with 18 titles. The Los Angeles Lakers are close behind with 17 championships.",
      difficulty: "medium"
    },
    {
      id: "bb_p5",
      question: "What is Giannis Antetokounmpo's jersey number?",
      options: [
        "34",
        "23",
        "30",
        "6"
      ],
      correctAnswer: 0, // A - 34
      explanation: "Giannis Antetokounmpo, known as 'The Greek Freak,' wears jersey number 34 for the Milwaukee Bucks.",
      difficulty: "medium"
    },
    {
      id: "bb_p6",
      question: "Which player was nicknamed 'The Black Mamba'?",
      options: [
        "Michael Jordan",
        "Shaquille O'Neal",
        "Kobe Bryant",
        "Allen Iverson"
      ],
      correctAnswer: 2, // C - Kobe Bryant
      explanation: "Kobe Bryant gave himself the nickname 'The Black Mamba' after the deadly snake, representing his aggressive and fearless playing style on the court.",
      difficulty: "easy"
    },
    {
      id: "bb_p7",
      question: "What was Kobe Bryant's jersey number(s)?",
      options: [
        "23 only",
        "24 only",
        "8 only",
        "Both 8 and 24"
      ],
      correctAnswer: 3, // D - Both 8 and 24
      explanation: "Kobe Bryant wore two different jersey numbers during his career with the Lakers: #8 from 1996-2006, and #24 from 2006-2016. Both numbers have been retired by the team in his honor.",
      difficulty: "medium"
    },
    {
      id: "bb_p8",
      question: "Which NBA player is known for his signature 'Step Back' three-point shot?",
      options: [
        "LeBron James",
        "Kevin Durant",
        "James Harden",
        "Luka Dončić"
      ],
      correctAnswer: 2, // C - James Harden
      explanation: "James Harden is famous for his step-back three-point shot, which has become his signature move. He creates space by stepping back before shooting, making it difficult for defenders to block.",
      difficulty: "medium"
    },
    {
      id: "bb_p9",
      question: "What is Kevin Durant's jersey number with the Phoenix Suns?",
      options: [
        "7",
        "35",
        "0",
        "23"
      ],
      correctAnswer: 0, // A - 7
      explanation: "Kevin Durant wears jersey number 7 with the Phoenix Suns. He previously wore #35 with the Oklahoma City Thunder and Golden State Warriors, and #7 with the Brooklyn Nets.",
      difficulty: "medium"
    },
    {
      id: "bb_p10",
      question: "Which player has the most three-pointers in NBA history?",
      options: [
        "Ray Allen",
        "Reggie Miller",
        "Stephen Curry",
        "James Harden"
      ],
      correctAnswer: 2, // C - Stephen Curry
      explanation: "Stephen Curry holds the record for the most three-pointers in NBA history, surpassing Ray Allen's previous record in December 2021. He continues to extend this record with his incredible shooting.",
      difficulty: "medium"
    },
    {
      id: "bb_p11",
      question: "What is Luka Dončić's jersey number?",
      options: [
        "23",
        "77",
        "7",
        "3"
      ],
      correctAnswer: 1, // B - 77
      explanation: "Luka Dončić wears jersey number 77 for the Dallas Mavericks. He chose this number because he wore #7 in Europe, but it was already taken when he joined the Mavericks.",
      difficulty: "medium"
    },
    {
      id: "bb_p12",
      question: "Which NBA player has the nickname 'The Joker'?",
      options: [
        "Nikola Jokić",
        "Joel Embiid",
        "Giannis Antetokounmpo",
        "Luka Dončić"
      ],
      correctAnswer: 0, // A - Nikola Jokić
      explanation: "Nikola Jokić is nicknamed 'The Joker,' which is a play on his last name and also represents his playful personality and creative playing style.",
      difficulty: "medium"
    },
    {
      id: "bb_p13",
      question: "What is Joel Embiid's jersey number?",
      options: [
        "21",
        "13",
        "34",
        "23"
      ],
      correctAnswer: 0, // A - 21
      explanation: "Joel Embiid wears jersey number 21 for the Philadelphia 76ers. He chose this number in honor of NBA legend Tim Duncan, who was his favorite player growing up.",
      difficulty: "medium"
    },
    {
      id: "bb_p14",
      question: "Which player won the NBA Rookie of the Year award in 2024?",
      options: [
        "Victor Wembanyama",
        "Chet Holmgren",
        "Scoot Henderson",
        "Brandon Miller"
      ],
      correctAnswer: 0, // A - Victor Wembanyama
      explanation: "Victor Wembanyama won the NBA Rookie of the Year award for the 2023-2024 season. The 7'4\" French phenom had an outstanding first season with the San Antonio Spurs.",
      difficulty: "hard"
    },
    {
      id: "bb_p15",
      question: "What is Jayson Tatum's jersey number?",
      options: [
        "0",
        "7",
        "11",
        "23"
      ],
      correctAnswer: 0, // A - 0
      explanation: "Jayson Tatum wears jersey number 0 for the Boston Celtics. He chose this number because his favorite player growing up was Gilbert Arenas, who also wore #0.",
      difficulty: "medium"
    }
  ],
  
  teen: [
    {
      id: "bb_t1",
      question: "Which player holds the record for most points scored in a single NBA season?",
      options: [
        "Michael Jordan",
        "Wilt Chamberlain",
        "Kobe Bryant",
        "James Harden"
      ],
      correctAnswer: 1, // B - Wilt Chamberlain
      explanation: "Wilt Chamberlain holds the record for most points in a single season with 4,029 points during the 1961-62 season, when he averaged an incredible 50.4 points per game.",
      difficulty: "hard"
    },
    {
      id: "bb_t2",
      question: "Which NBA player has the highest career points per game average?",
      options: [
        "LeBron James",
        "Kobe Bryant",
        "Michael Jordan",
        "Wilt Chamberlain"
      ],
      correctAnswer: 2, // C - Michael Jordan
      explanation: "Michael Jordan has the highest career scoring average in NBA history at 30.12 points per game. Wilt Chamberlain is second at 30.07 points per game.",
      difficulty: "hard"
    },
    {
      id: "bb_t3",
      question: "What is Nikola Jokić's jersey number?",
      options: [
        "15",
        "21",
        "13",
        "45"
      ],
      correctAnswer: 0, // A - 15
      explanation: "Nikola Jokić wears jersey number 15 for the Denver Nuggets. He has worn this number throughout his NBA career since being drafted in 2014.",
      difficulty: "medium"
    },
    {
      id: "bb_t4",
      question: "Which player has won the most NBA Finals MVP awards?",
      options: [
        "LeBron James",
        "Michael Jordan",
        "Magic Johnson",
        "Shaquille O'Neal"
      ],
      correctAnswer: 1, // B - Michael Jordan
      explanation: "Michael Jordan has won the most NBA Finals MVP awards with 6, winning the award every time he reached the Finals. LeBron James is second with 4 Finals MVP awards.",
      difficulty: "hard"
    },
    {
      id: "bb_t5",
      question: "What is Ja Morant's jersey number?",
      options: [
        "12",
        "23",
        "1",
        "3"
      ],
      correctAnswer: 0, // A - 12
      explanation: "Ja Morant wears jersey number 12 for the Memphis Grizzlies. He's known for his explosive athleticism and highlight-reel dunks.",
      difficulty: "medium"
    },
    {
      id: "bb_t6",
      question: "Which player holds the record for most triple-doubles in NBA history?",
      options: [
        "Magic Johnson",
        "LeBron James",
        "Oscar Robertson",
        "Russell Westbrook"
      ],
      correctAnswer: 3, // D - Russell Westbrook
      explanation: "Russell Westbrook holds the NBA record for most career triple-doubles. He broke Oscar Robertson's long-standing record of 181 triple-doubles in 2021 and continues to extend the record.",
      difficulty: "hard"
    },
    {
      id: "bb_t7",
      question: "What is Devin Booker's jersey number?",
      options: [
        "1",
        "3",
        "23",
        "13"
      ],
      correctAnswer: 1, // B - 1
      explanation: "Devin Booker wears jersey number 1 for the Phoenix Suns. He previously wore #13 in college at Kentucky but switched to #1 in the NBA.",
      difficulty: "medium"
    },
    {
      id: "bb_t8",
      question: "Which player has the highest career three-point shooting percentage in NBA history (minimum 250 made)?",
      options: [
        "Stephen Curry",
        "Ray Allen",
        "Steve Kerr",
        "Klay Thompson"
      ],
      correctAnswer: 2, // C - Steve Kerr
      explanation: "Steve Kerr, current coach of the Golden State Warriors, holds the highest career three-point shooting percentage in NBA history at 45.4% (among players with at least 250 made three-pointers).",
      difficulty: "hard"
    },
    {
      id: "bb_t9",
      question: "What is Damian Lillard's jersey number with the Milwaukee Bucks?",
      options: [
        "0",
        "1",
        "7",
        "8"
      ],
      correctAnswer: 0, // A - 0
      explanation: "Damian Lillard wears jersey number 0 with the Milwaukee Bucks, the same number he wore during his time with the Portland Trail Blazers. The '0' represents the letter 'O' for Oakland, Oregon, and Ogden - places important to his life journey.",
      difficulty: "medium"
    },
    {
      id: "bb_t10",
      question: "Which NBA player has the nickname 'Dame Time'?",
      options: [
        "Damian Lillard",
        "LaMelo Ball",
        "Trae Young",
        "Kyrie Irving"
      ],
      correctAnswer: 0, // A - Damian Lillard
      explanation: "Damian Lillard is known as 'Dame Time' because of his clutch performances in late-game situations. He often points to his wrist, indicating 'it's Dame Time' after hitting big shots in crucial moments.",
      difficulty: "medium"
    },
    {
      id: "bb_t11",
      question: "What is Anthony Edwards' jersey number?",
      options: [
        "1",
        "5",
        "23",
        "3"
      ],
      correctAnswer: 0, // A - 1
      explanation: "Anthony Edwards wears jersey number 1 for the Minnesota Timberwolves. He was the #1 overall pick in the 2020 NBA Draft.",
      difficulty: "medium"
    },
    {
      id: "bb_t12",
      question: "Which player has the most 50-point games in NBA history?",
      options: [
        "Michael Jordan",
        "Kobe Bryant",
        "Wilt Chamberlain",
        "James Harden"
      ],
      correctAnswer: 2, // C - Wilt Chamberlain
      explanation: "Wilt Chamberlain has by far the most 50-point games in NBA history with 118. For perspective, Michael Jordan is second with 31 such games.",
      difficulty: "hard"
    },
    {
      id: "bb_t13",
      question: "What is Zion Williamson's jersey number?",
      options: [
        "1",
        "23",
        "34",
        "9"
      ],
      correctAnswer: 0, // A - 1
      explanation: "Zion Williamson wears jersey number 1 for the New Orleans Pelicans. He was the #1 overall pick in the 2019 NBA Draft.",
      difficulty: "medium"
    },
    {
      id: "bb_t14",
      question: "Which player has won the most NBA Defensive Player of the Year awards?",
      options: [
        "Hakeem Olajuwon",
        "Dikembe Mutombo",
        "Rudy Gobert",
        "Ben Wallace"
      ],
      correctAnswer: 2, // C - Rudy Gobert
      explanation: "Rudy Gobert has won the NBA Defensive Player of the Year award four times (2018, 2019, 2021, 2022), tied with Dikembe Mutombo and Ben Wallace for the most in NBA history.",
      difficulty: "hard"
    },
    {
      id: "bb_t15",
      question: "What is Trae Young's jersey number?",
      options: [
        "11",
        "3",
        "1",
        "23"
      ],
      correctAnswer: 1, // B - 11
      explanation: "Trae Young wears jersey number 11 for the Atlanta Hawks. He's known for his long-range shooting and playmaking abilities.",
      difficulty: "medium"
    }
  ],
  
  adult: [
    {
      id: "bb_a1",
      question: "Which player has the highest Player Efficiency Rating (PER) in NBA history?",
      options: [
        "LeBron James",
        "Michael Jordan",
        "Wilt Chamberlain",
        "Nikola Jokić"
      ],
      correctAnswer: 3, // D - Nikola Jokić
      explanation: "As of the 2023-24 season, Nikola Jokić has surpassed Michael Jordan for the highest career Player Efficiency Rating (PER) in NBA history. This advanced statistic measures a player's per-minute productivity.",
      difficulty: "hard"
    },
    {
      id: "bb_a2",
      question: "Which NBA player has the highest career true shooting percentage (minimum 10,000 points)?",
      options: [
        "Stephen Curry",
        "Kevin Durant",
        "Artis Gilmore",
        "John Stockton"
      ],
      correctAnswer: 0, // A - Stephen Curry
      explanation: "Stephen Curry has the highest career true shooting percentage (TS%) among players with at least 10,000 career points. True shooting percentage accounts for field goals, three-pointers, and free throws.",
      difficulty: "hard"
    },
    {
      id: "bb_a3",
      question: "What is Victor Wembanyama's jersey number?",
      options: [
        "1",
        "9",
        "34",
        "4"
      ],
      correctAnswer: 1, // B - 1
      explanation: "Victor Wembanyama wears jersey number 1 for the San Antonio Spurs. The 7'4\" French phenom was the #1 overall pick in the 2023 NBA Draft.",
      difficulty: "medium"
    },
    {
      id: "bb_a4",
      question: "Which player holds the record for most assists in a single NBA game?",
      options: [
        "Magic Johnson",
        "John Stockton",
        "Scott Skiles",
        "Isiah Thomas"
      ],
      correctAnswer: 2, // C - Scott Skiles
      explanation: "Scott Skiles holds the NBA record for most assists in a single game with 30, set on December 30, 1990, while playing for the Orlando Magic against the Denver Nuggets.",
      difficulty: "hard"
    },
    {
      id: "bb_a5",
      question: "What is Tyrese Haliburton's jersey number?",
      options: [
        "0",
        "3",
        "15",
        "11"
      ],
      correctAnswer: 0, // A - 0
      explanation: "Tyrese Haliburton wears jersey number 0 for the Indiana Pacers. He previously wore #0 with the Sacramento Kings as well.",
      difficulty: "medium"
    },
    {
      id: "bb_a6",
      question: "Which player has the highest career Win Shares per 48 minutes in NBA history?",
      options: [
        "Michael Jordan",
        "LeBron James",
        "Kareem Abdul-Jabbar",
        "Chris Paul"
      ],
      correctAnswer: 0, // A - Michael Jordan
      explanation: "Michael Jordan has the highest career Win Shares per 48 minutes in NBA history at .2505, slightly ahead of David Robinson (.2501). This advanced statistic estimates the number of wins a player contributes per 48 minutes played.",
      difficulty: "hard"
    },
    {
      id: "bb_a7",
      question: "What is Shai Gilgeous-Alexander's jersey number?",
      options: [
        "2",
        "13",
        "23",
        "32"
      ],
      correctAnswer: 0, // A - 2
      explanation: "Shai Gilgeous-Alexander wears jersey number 2 for the Oklahoma City Thunder. He previously wore #2 with the Los Angeles Clippers as well.",
      difficulty: "medium"
    },
    {
      id: "bb_a8",
      question: "Which player has the highest career Box Plus/Minus (BPM) in NBA history?",
      options: [
        "LeBron James",
        "Michael Jordan",
        "Nikola Jokić",
        "Chris Paul"
      ],
      correctAnswer: 2, // C - Nikola Jokić
      explanation: "Nikola Jokić has the highest career Box Plus/Minus (BPM) in NBA history. BPM is an advanced statistic that estimates a player's contribution in points above league average per 100 possessions.",
      difficulty: "hard"
    },
    {
      id: "bb_a9",
      question: "What is Paolo Banchero's jersey number?",
      options: [
        "5",
        "1",
        "13",
        "23"
      ],
      correctAnswer: 1, // B - 5
      explanation: "Paolo Banchero wears jersey number 5 for the Orlando Magic. He was the #1 overall pick in the 2022 NBA Draft.",
      difficulty: "medium"
    },
    {
      id: "bb_a10",
      question: "Which player has the highest career Offensive Rating (minimum 15,000 minutes played)?",
      options: [
        "Stephen Curry",
        "James Harden",
        "Chris Paul",
        "Nikola Jokić"
      ],
      correctAnswer: 0, // A - Stephen Curry
      explanation: "Stephen Curry has the highest career Offensive Rating among players with at least 15,000 minutes played. Offensive Rating measures points produced per 100 possessions.",
      difficulty: "hard"
    },
    {
      id: "bb_a11",
      question: "What is Cade Cunningham's jersey number?",
      options: [
        "2",
        "1",
        "7",
        "23"
      ],
      correctAnswer: 1, // B - 2
      explanation: "Cade Cunningham wears jersey number 2 for the Detroit Pistons. He was the #1 overall pick in the 2021 NBA Draft.",
      difficulty: "medium"
    },
    {
      id: "bb_a12",
      question: "Which player has the highest career Defensive Rating (minimum 15,000 minutes played)?",
      options: [
        "Tim Duncan",
        "Rudy Gobert",
        "Ben Wallace",
        "Dikembe Mutombo"
      ],
      correctAnswer: 1, // B - Rudy Gobert
      explanation: "Rudy Gobert has the highest career Defensive Rating among players with at least 15,000 minutes played. Defensive Rating estimates how many points a player allows per 100 possessions.",
      difficulty: "hard"
    },
    {
      id: "bb_a13",
      question: "What is Jalen Brunson's jersey number?",
      options: [
        "11",
        "13",
        "1",
        "23"
      ],
      correctAnswer: 0, // A - 11
      explanation: "Jalen Brunson wears jersey number 11 for the New York Knicks. He previously wore #13 with the Dallas Mavericks.",
      difficulty: "medium"
    },
    {
      id: "bb_a14",
      question: "Which player has the highest career Usage Percentage in NBA history (minimum 15,000 minutes played)?",
      options: [
        "Michael Jordan",
        "Kobe Bryant",
        "Russell Westbrook",
        "James Harden"
      ],
      correctAnswer: 0, // A - Michael Jordan
      explanation: "Michael Jordan has the highest career Usage Percentage in NBA history at 33.3% among players with at least 15,000 minutes played. Usage Percentage estimates the percentage of team plays used by a player while on the floor.",
      difficulty: "hard"
    },
    {
      id: "bb_a15",
      question: "What is Scottie Barnes' jersey number?",
      options: [
        "4",
        "1",
        "23",
        "13"
      ],
      correctAnswer: 0, // A - 4
      explanation: "Scottie Barnes wears jersey number 4 for the Toronto Raptors. He was the 4th overall pick in the 2021 NBA Draft and won Rookie of the Year for the 2021-22 season.",
      difficulty: "medium"
    }
  ]
};
