// Current Baseball Trivia Questions
// This file contains current baseball trivia questions for the "Oh my Skibity Sigma" game

const currentBaseballTrivia = {
  kid: [
    {
      id: "cb_k1",
      question: "Which team won the most recent World Series?",
      options: [
        "Los Angeles Dodgers",
        "Texas Rangers",
        "Boston Celtics",
        "New York Yankees"
      ],
      correctAnswer: 0, // A - Los Angeles Dodgers (as of 2024)
      explanation: "The Los Angeles Dodgers won the 2023 World Series, defeating the Texas Rangers. The Dodgers have a long history as one of baseball's most successful teams!",
      difficulty: "easy"
    },
    {
      id: "cb_k2",
      question: "What is the name of the baseball stadium where the New York Yankees play?",
      options: [
        "Fenway Park",
        "Wrigley Field",
        "Yankee Stadium",
        "Dodger Stadium"
      ],
      correctAnswer: 2, // C - Yankee Stadium
      explanation: "The New York Yankees play at Yankee Stadium in the Bronx, New York. The current Yankee Stadium opened in 2009, replacing the original Yankee Stadium that was built in 1923.",
      difficulty: "easy"
    },
    {
      id: "cb_k3",
      question: "Which of these is NOT a position in baseball?",
      options: [
        "Shortstop",
        "Quarterback",
        "Pitcher",
        "Catcher"
      ],
      correctAnswer: 1, // B - Quarterback
      explanation: "Quarterback is not a position in baseball - it's a position in football! Shortstop, pitcher, and catcher are all baseball positions.",
      difficulty: "easy"
    },
    {
      id: "cb_k4",
      question: "How many players are on the field for each team during a baseball game?",
      options: [
        "7 players",
        "9 players",
        "11 players",
        "12 players"
      ],
      correctAnswer: 1, // B - 9 players
      explanation: "Each team has 9 players on the field during a baseball game: a pitcher, catcher, first baseman, second baseman, third baseman, shortstop, left fielder, center fielder, and right fielder.",
      difficulty: "easy"
    },
    {
      id: "cb_k5",
      question: "What is it called when a batter hits the ball over the outfield fence in fair territory?",
      options: [
        "Touchdown",
        "Home run",
        "Strike",
        "Foul ball"
      ],
      correctAnswer: 1, // B - Home run
      explanation: "When a batter hits the ball over the outfield fence in fair territory, it's called a home run! The batter gets to run around all the bases and score a run.",
      difficulty: "easy"
    },
    {
      id: "cb_k6",
      question: "Which of these is NOT one of the bases on a baseball field?",
      options: [
        "First base",
        "Second base",
        "Fifth base",
        "Home plate"
      ],
      correctAnswer: 2, // C - Fifth base
      explanation: "Fifth base does not exist on a baseball field! There are only four bases: first base, second base, third base, and home plate.",
      difficulty: "easy"
    },
    {
      id: "cb_k7",
      question: "What is the name of the Los Angeles baseball team that wears blue?",
      options: [
        "Los Angeles Angels",
        "Los Angeles Dodgers",
        "Los Angeles Lakers",
        "Los Angeles Rams"
      ],
      correctAnswer: 1, // B - Los Angeles Dodgers
      explanation: "The Los Angeles Dodgers wear blue as their primary color. The Los Angeles Angels are the other MLB team in the Los Angeles area, while the Lakers and Rams are basketball and football teams.",
      difficulty: "easy"
    },
    {
      id: "cb_k8",
      question: "What do you call it when a pitcher throws three strikes to a batter?",
      options: [
        "Strikeout",
        "Home run",
        "Walk",
        "Foul ball"
      ],
      correctAnswer: 0, // A - Strikeout
      explanation: "When a pitcher throws three strikes to a batter, it's called a strikeout! The batter is out and has to return to the dugout.",
      difficulty: "easy"
    },
    {
      id: "cb_k9",
      question: "Which of these is used to hit the baseball?",
      options: [
        "Racket",
        "Club",
        "Bat",
        "Stick"
      ],
      correctAnswer: 2, // C - Bat
      explanation: "A bat is used to hit the baseball. Baseball bats are typically made of wood (in professional baseball) or aluminum (in youth and amateur baseball).",
      difficulty: "easy"
    },
    {
      id: "cb_k10",
      question: "What is the name of the baseball team from Boston?",
      options: [
        "Boston Bruins",
        "Boston Red Sox",
        "Boston Celtics",
        "Boston Patriots"
      ],
      correctAnswer: 1, // B - Boston Red Sox
      explanation: "The Boston Red Sox are the Major League Baseball team from Boston. The Bruins (hockey), Celtics (basketball), and Patriots (football) are other professional sports teams from the Boston area.",
      difficulty: "easy"
    },
    {
      id: "cb_k11",
      question: "What is the name of the championship trophy in Major League Baseball?",
      options: [
        "Stanley Cup",
        "Commissioner's Trophy",
        "Vince Lombardi Trophy",
        "Larry O'Brien Trophy"
      ],
      correctAnswer: 1, // B - Commissioner's Trophy
      explanation: "The Commissioner's Trophy is awarded to the team that wins the World Series in Major League Baseball. The other trophies are for hockey (Stanley Cup), football (Vince Lombardi Trophy), and basketball (Larry O'Brien Trophy).",
      difficulty: "medium"
    },
    {
      id: "cb_k12",
      question: "How many innings are in a standard baseball game?",
      options: [
        "7 innings",
        "9 innings",
        "12 innings",
        "15 innings"
      ],
      correctAnswer: 1, // B - 9 innings
      explanation: "A standard baseball game has 9 innings. If the score is tied after 9 innings, the game goes into extra innings until there's a winner.",
      difficulty: "easy"
    },
    {
      id: "cb_k13",
      question: "What color are the seats at Fenway Park, home of the Boston Red Sox?",
      options: [
        "Blue",
        "Red",
        "Green",
        "Yellow"
      ],
      correctAnswer: 2, // C - Green
      explanation: "The seats at Fenway Park are green. Fenway Park is famous for its 'Green Monster,' a 37-foot-tall green wall in left field.",
      difficulty: "medium"
    },
    {
      id: "cb_k14",
      question: "Which baseball player is known as 'The Bambino' or 'The Sultan of Swat'?",
      options: [
        "Babe Ruth",
        "Mickey Mantle",
        "Joe DiMaggio",
        "Ted Williams"
      ],
      correctAnswer: 0, // A - Babe Ruth
      explanation: "Babe Ruth was known as 'The Bambino' or 'The Sultan of Swat.' He was one of the greatest baseball players of all time and played for the Boston Red Sox and New York Yankees.",
      difficulty: "medium"
    },
    {
      id: "cb_k15",
      question: "What is the name of the baseball team from Chicago that wears white and blue and has a 'C' on their caps?",
      options: [
        "Chicago White Sox",
        "Chicago Cubs",
        "Chicago Bears",
        "Chicago Bulls"
      ],
      correctAnswer: 1, // B - Chicago Cubs
      explanation: "The Chicago Cubs wear white and blue uniforms and have a 'C' on their caps. Chicago has two Major League Baseball teams: the Cubs and the White Sox.",
      difficulty: "easy"
    }
  ],
  
  adult: [
    {
      id: "cb_a1",
      question: "Which MLB player won the 2023 American League MVP award?",
      options: [
        "Aaron Judge",
        "Shohei Ohtani",
        "Juan Soto",
        "Vladimir Guerrero Jr."
      ],
      correctAnswer: 1, // B - Shohei Ohtani
      explanation: "Shohei Ohtani won the 2023 American League MVP award while playing for the Los Angeles Angels. He had a historic season as both a pitcher and hitter before signing with the Los Angeles Dodgers in the offseason.",
      difficulty: "medium"
    },
    {
      id: "cb_a2",
      question: "Which team had the best regular season record in MLB in 2023?",
      options: [
        "Los Angeles Dodgers",
        "Atlanta Braves",
        "Houston Astros",
        "New York Yankees"
      ],
      correctAnswer: 1, // B - Atlanta Braves
      explanation: "The Atlanta Braves had the best regular season record in MLB in 2023 with 104 wins and 58 losses. Despite this impressive record, they were eliminated in the Division Series by the Philadelphia Phillies.",
      difficulty: "medium"
    },
    {
      id: "cb_a3",
      question: "Which pitcher led MLB in strikeouts for the 2023 season?",
      options: [
        "Gerrit Cole",
        "Spencer Strider",
        "Kevin Gausman",
        "Zack Wheeler"
      ],
      correctAnswer: 1, // B - Spencer Strider
      explanation: "Spencer Strider of the Atlanta Braves led MLB in strikeouts for the 2023 season with 281 strikeouts. He was a dominant force on the mound for the Braves.",
      difficulty: "hard"
    },
    {
      id: "cb_a4",
      question: "Which MLB team signed Shohei Ohtani to a record-breaking contract in December 2023?",
      options: [
        "New York Yankees",
        "Los Angeles Dodgers",
        "Boston Red Sox",
        "San Francisco Giants"
      ],
      correctAnswer: 1, // B - Los Angeles Dodgers
      explanation: "The Los Angeles Dodgers signed Shohei Ohtani to a record-breaking 10-year, $700 million contract in December 2023. The deal included significant deferrals of salary to later years, allowing the Dodgers more flexibility to sign other players.",
      difficulty: "medium"
    },
    {
      id: "cb_a5",
      question: "Which MLB player led the league in home runs for the 2023 season?",
      options: [
        "Aaron Judge",
        "Shohei Ohtani",
        "Matt Olson",
        "Pete Alonso"
      ],
      correctAnswer: 2, // C - Matt Olson
      explanation: "Matt Olson of the Atlanta Braves led MLB in home runs for the 2023 season with 54 home runs. This was a career-high for Olson and set a new Atlanta Braves franchise record.",
      difficulty: "hard"
    },
    {
      id: "cb_a6",
      question: "Which team won the 2023 World Series?",
      options: [
        "Texas Rangers",
        "Philadelphia Phillies",
        "Los Angeles Dodgers",
        "Arizona Diamondbacks"
      ],
      correctAnswer: 0, // A - Texas Rangers
      explanation: "The Texas Rangers won the 2023 World Series, defeating the Arizona Diamondbacks in five games. It was the first World Series championship in Rangers franchise history.",
      difficulty: "medium"
    },
    {
      id: "cb_a7",
      question: "Which MLB player had the highest batting average in the 2023 season?",
      options: [
        "Luis Arraez",
        "Freddie Freeman",
        "Corey Seager",
        "Yandy Díaz"
      ],
      correctAnswer: 0, // A - Luis Arraez
      explanation: "Luis Arraez of the Miami Marlins had the highest batting average in the 2023 season at .354. He became the first Marlins player to win a batting title and nearly reached .400 early in the season.",
      difficulty: "hard"
    },
    {
      id: "cb_a8",
      question: "Which MLB team hired Craig Counsell as their new manager for the 2024 season?",
      options: [
        "New York Mets",
        "Chicago Cubs",
        "Milwaukee Brewers",
        "Boston Red Sox"
      ],
      correctAnswer: 1, // B - Chicago Cubs
      explanation: "The Chicago Cubs hired Craig Counsell as their new manager for the 2024 season, signing him to a record-breaking 5-year, $40 million contract. Counsell had previously managed the Milwaukee Brewers for 9 seasons.",
      difficulty: "medium"
    },
    {
      id: "cb_a9",
      question: "Which MLB team drafted Paul Skenes with the first overall pick in the 2023 MLB Draft?",
      options: [
        "Washington Nationals",
        "Oakland Athletics",
        "Pittsburgh Pirates",
        "Detroit Tigers"
      ],
      correctAnswer: 2, // C - Pittsburgh Pirates
      explanation: "The Pittsburgh Pirates drafted Paul Skenes, a pitcher from LSU, with the first overall pick in the 2023 MLB Draft. Skenes was considered one of the best college pitching prospects in recent years.",
      difficulty: "hard"
    },
    {
      id: "cb_a10",
      question: "Which MLB player won the 2023 National League Cy Young Award?",
      options: [
        "Zack Wheeler",
        "Blake Snell",
        "Logan Webb",
        "Justin Steele"
      ],
      correctAnswer: 1, // B - Blake Snell
      explanation: "Blake Snell of the San Diego Padres won the 2023 National League Cy Young Award. He led the National League with a 2.25 ERA and 234 strikeouts in 180 innings pitched.",
      difficulty: "hard"
    },
    {
      id: "cb_a11",
      question: "Which MLB team relocated their spring training facility to Las Vegas for the 2023 season?",
      options: [
        "Oakland Athletics",
        "Arizona Diamondbacks",
        "Colorado Rockies",
        "Los Angeles Angels"
      ],
      correctAnswer: 0, // A - Oakland Athletics
      explanation: "The Oakland Athletics relocated their spring training facility to Las Vegas for the 2023 season, moving from their previous location in Mesa, Arizona. This move came as the team was also pursuing a permanent relocation to Las Vegas.",
      difficulty: "hard"
    },
    {
      id: "cb_a12",
      question: "Which MLB player won the 2023 World Series MVP award?",
      options: [
        "Corey Seager",
        "Adolis García",
        "Marcus Semien",
        "Nathan Eovaldi"
      ],
      correctAnswer: 0, // A - Corey Seager
      explanation: "Corey Seager of the Texas Rangers won the 2023 World Series MVP award. He hit .286 with 3 home runs and 6 RBIs in the World Series against the Arizona Diamondbacks.",
      difficulty: "medium"
    },
    {
      id: "cb_a13",
      question: "Which MLB team had the longest winning streak during the 2023 season?",
      options: [
        "Atlanta Braves",
        "Tampa Bay Rays",
        "Seattle Mariners",
        "Baltimore Orioles"
      ],
      correctAnswer: 1, // B - Tampa Bay Rays
      explanation: "The Tampa Bay Rays had the longest winning streak during the 2023 season, winning 13 consecutive games to start the season. This set a modern era record for the longest winning streak to begin a season.",
      difficulty: "hard"
    },
    {
      id: "cb_a14",
      question: "Which MLB stadium introduced a new 'Seating Bowl' renovation for the 2023 season?",
      options: [
        "Fenway Park",
        "Wrigley Field",
        "Dodger Stadium",
        "Yankee Stadium"
      ],
      correctAnswer: 1, // B - Wrigley Field
      explanation: "Wrigley Field, home of the Chicago Cubs, introduced a new 'Seating Bowl' renovation for the 2023 season. The renovation included new premium clubs, improved sightlines, and updated amenities while preserving the historic character of the ballpark.",
      difficulty: "hard"
    },
    {
      id: "cb_a15",
      question: "Which MLB team signed Juan Soto in a blockbuster trade before the 2024 season?",
      options: [
        "Boston Red Sox",
        "New York Yankees",
        "Los Angeles Dodgers",
        "Philadelphia Phillies"
      ],
      correctAnswer: 1, // B - New York Yankees
      explanation: "The New York Yankees acquired Juan Soto in a blockbuster trade with the San Diego Padres before the 2024 season. The Yankees sent multiple players to the Padres in exchange for Soto, who is considered one of the best young hitters in baseball.",
      difficulty: "medium"
    }
  ]
};
