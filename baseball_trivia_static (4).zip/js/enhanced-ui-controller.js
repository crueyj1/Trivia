// Enhanced UI Controller for Oh my Skibity Sigma
// This file updates the user interface to support all new features

// DOM Elements
let gameContainer;
let welcomeScreen;
let gameScreen;
let resultScreen;
let categorySelector;
let modeSelector;
let difficultySelector;
let gameTypeSelector;
let playerSetupForm;
let questionDisplay;
let answerOptions;
let resultDisplay;
let scoreDisplay;
let nextButton;
let mainMenuButton;

// Initialize the UI when the DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  // Initialize game logic
  initializeGame();
  
  // Get DOM elements
  gameContainer = document.getElementById('game-container');
  
  // Render initial game state
  renderGameState();
  
  // Add event listeners for global UI elements
  document.addEventListener('keydown', function(event) {
    // Handle keyboard shortcuts for answering
    if (gameState.gameStatus === GAME_STATUS.PLAYING) {
      const key = event.key.toUpperCase();
      if (['A', 'B', 'C', 'D'].includes(key)) {
        submitAnswer(key);
      }
    }
  });
});

// Main render function - updates UI based on game state
function renderGameState() {
  // Clear the game container
  gameContainer.innerHTML = '';
  
  // Render the appropriate screen based on game status
  switch (gameState.gameStatus) {
    case GAME_STATUS.WELCOME:
      renderWelcomeScreen();
      break;
    case GAME_STATUS.SETUP_MULTIPLAYER:
      renderMultiplayerSetup();
      break;
    case GAME_STATUS.PLAYING:
      renderGameScreen();
      break;
    case GAME_STATUS.ANSWERED:
      renderAnswerResult();
      break;
    case GAME_STATUS.ROUND_END:
      renderRoundResults();
      break;
    case GAME_STATUS.SERIES_END:
      renderSeriesResults();
      break;
    case GAME_STATUS.FINISHED:
      renderGameOver();
      break;
    default:
      renderWelcomeScreen();
  }
}

// Render the welcome screen with game options
function renderWelcomeScreen() {
  const welcomeScreen = document.createElement('div');
  welcomeScreen.className = 'welcome-screen';
  
  welcomeScreen.innerHTML = `
    <div class="game-logo">
      <h1>Oh my Skibity Sigma</h1>
      <p class="tagline">The Ultimate Trivia Challenge!</p>
    </div>
    
    <div class="game-options">
      <div class="option-group">
        <h2>Game Mode</h2>
        <div class="toggle-container">
          <button class="toggle-btn ${gameState.gameMode === GAME_MODE.KID ? 'active' : ''}" data-mode="${GAME_MODE.KID}">Kid Mode</button>
          <button class="toggle-btn ${gameState.gameMode === GAME_MODE.ADULT ? 'active' : ''}" data-mode="${GAME_MODE.ADULT}">Adult Mode</button>
        </div>
      </div>
      
      <div class="option-group">
        <h2>Question Category</h2>
        <div class="category-selector">
          <button class="category-btn ${gameState.categoryType === CATEGORY_TYPE.FIELDING ? 'active' : ''}" data-category="${CATEGORY_TYPE.FIELDING}">
            <span class="icon">⚾</span>
            <span class="label">Baseball Fielding</span>
          </button>
          <button class="category-btn ${gameState.categoryType === CATEGORY_TYPE.CURRENT ? 'active' : ''}" data-category="${CATEGORY_TYPE.CURRENT}">
            <span class="icon">🏆</span>
            <span class="label">Current Baseball</span>
          </button>
          <button class="category-btn ${gameState.categoryType === CATEGORY_TYPE.BASKETBALL ? 'active' : ''}" data-category="${CATEGORY_TYPE.BASKETBALL}">
            <span class="icon">🏀</span>
            <span class="label">Basketball</span>
          </button>
          <button class="category-btn ${gameState.categoryType === CATEGORY_TYPE.GEOGRAPHY ? 'active' : ''}" data-category="${CATEGORY_TYPE.GEOGRAPHY}">
            <span class="icon">🌎</span>
            <span class="label">Geography</span>
          </button>
          <button class="category-btn ${gameState.categoryType === CATEGORY_TYPE.MATHEMATICS ? 'active' : ''}" data-category="${CATEGORY_TYPE.MATHEMATICS}">
            <span class="icon">🔢</span>
            <span class="label">Mathematics</span>
          </button>
        </div>
      </div>
      
      <div class="option-group">
        <h2>Game Type</h2>
        <div class="game-type-selector">
          <button class="game-type-btn" data-type="${GAME_TYPE.SINGLE}">
            <span class="icon">👤</span>
            <span class="label">Single Player</span>
          </button>
          <button class="game-type-btn" data-type="${GAME_TYPE.MULTIPLAYER}">
            <span class="icon">👥</span>
            <span class="label">Multiplayer</span>
          </button>
        </div>
      </div>
    </div>
  `;
  
  // Add event listeners
  const modeButtons = welcomeScreen.querySelectorAll('.toggle-btn');
  modeButtons.forEach(button => {
    button.addEventListener('click', function() {
      const mode = this.dataset.mode;
      setGameMode(mode);
      
      // Update UI
      modeButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
    });
  });
  
  const categoryButtons = welcomeScreen.querySelectorAll('.category-btn');
  categoryButtons.forEach(button => {
    button.addEventListener('click', function() {
      const category = this.dataset.category;
      setCategoryType(category);
      
      // Update UI
      categoryButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
    });
  });
  
  const gameTypeButtons = welcomeScreen.querySelectorAll('.game-type-btn');
  gameTypeButtons.forEach(button => {
    button.addEventListener('click', function() {
      const type = this.dataset.type;
      setGameType(type);
      
      if (type === GAME_TYPE.SINGLE) {
        startNewGame();
      }
      
      renderGameState();
    });
  });
  
  gameContainer.appendChild(welcomeScreen);
}

// Render the multiplayer setup screen
function renderMultiplayerSetup() {
  const setupScreen = document.createElement('div');
  setupScreen.className = 'multiplayer-setup';
  
  setupScreen.innerHTML = `
    <h2>Multiplayer Setup</h2>
    <p class="setup-info">Enter player names and ages (ages 5-99)</p>
    
    <form id="player-setup-form">
      <div class="player-inputs">
        <div class="player-input">
          <label for="player1">Player 1</label>
          <input type="text" id="player1-name" placeholder="Name" required>
          <input type="number" id="player1-age" placeholder="Age" min="5" max="99" required>
        </div>
        
        <div class="player-input">
          <label for="player2">Player 2</label>
          <input type="text" id="player2-name" placeholder="Name" required>
          <input type="number" id="player2-age" placeholder="Age" min="5" max="99" required>
        </div>
      </div>
      
      <div class="add-player-container">
        <button type="button" id="add-player-btn" class="btn">Add Player</button>
        <span class="player-count">(2/4 Players)</span>
      </div>
      
      <div class="setup-buttons">
        <button type="submit" class="btn start-btn">Start Game</button>
        <button type="button" class="btn back-btn">Back</button>
      </div>
    </form>
  `;
  
  gameContainer.appendChild(setupScreen);
  
  // Get form elements
  const playerForm = document.getElementById('player-setup-form');
  const addPlayerBtn = document.getElementById('add-player-btn');
  const playerCount = document.querySelector('.player-count');
  const playerInputs = document.querySelector('.player-inputs');
  const backBtn = document.querySelector('.back-btn');
  
  // Track number of players
  let numPlayers = 2;
  
  // Add player button
  addPlayerBtn.addEventListener('click', function() {
    if (numPlayers < 4) {
      numPlayers++;
      
      const newPlayerInput = document.createElement('div');
      newPlayerInput.className = 'player-input';
      newPlayerInput.innerHTML = `
        <label for="player${numPlayers}">Player ${numPlayers}</label>
        <input type="text" id="player${numPlayers}-name" placeholder="Name" required>
        <input type="number" id="player${numPlayers}-age" placeholder="Age" min="5" max="99" required>
      `;
      
      playerInputs.appendChild(newPlayerInput);
      playerCount.textContent = `(${numPlayers}/4 Players)`;
      
      if (numPlayers === 4) {
        addPlayerBtn.disabled = true;
      }
    }
  });
  
  // Back button
  backBtn.addEventListener('click', function() {
    resetGame();
    renderGameState();
  });
  
  // Form submission
  playerForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Collect player data
    const playerData = [];
    
    for (let i = 1; i <= numPlayers; i++) {
      const nameInput = document.getElementById(`player${i}-name`);
      const ageInput = document.getElementById(`player${i}-age`);
      
      if (nameInput && ageInput) {
        playerData.push({
          name: nameInput.value.trim() || `Player ${i}`,
          age: parseInt(ageInput.value) || 11 // Default to 11 if invalid
        });
      }
    }
    
    // Setup multiplayer game
    setupMultiplayerGame(playerData);
    getNextQuestion();
    renderGameState();
  });
}

// Render the main game screen with question and answer options
function renderGameScreen() {
  if (!gameState.currentQuestion) {
    console.error('No current question available');
    return;
  }
  
  const gameScreen = document.createElement('div');
  gameScreen.className = 'game-screen';
  
  // Create header with game info
  const gameHeader = document.createElement('div');
  gameHeader.className = 'game-header';
  
  if (gameState.gameType === GAME_TYPE.MULTIPLAYER) {
    // Multiplayer header
    const currentPlayer = gameState.players[gameState.currentPlayerIndex];
    
    gameHeader.innerHTML = `
      <div class="game-info">
        <div class="round-info">Round ${gameState.currentRound}/3</div>
        <div class="question-counter">Question ${gameState.questionCount + 1}/${gameState.questionsPerRound}</div>
      </div>
      
      <div class="player-info">
        <div class="current-player">
          <span class="player-label">Current Player:</span>
          <span class="player-name">${currentPlayer.name}</span>
          <span class="player-age">(Age: ${currentPlayer.age})</span>
        </div>
      </div>
      
      <div class="scoreboard">
        ${gameState.players.map(player => `
          <div class="player-score ${player.isActive ? 'active' : ''}">
            <span class="score-name">${player.name}</span>
            <span class="score-value">${player.score}</span>
          </div>
        `).join('')}
      </div>
    `;
  } else {
    // Single player header
    gameHeader.innerHTML = `
      <div class="game-info">
        <div class="category-info">${getCategoryName(gameState.categoryType)}</div>
        <div class="mode-info">${gameState.gameMode === GAME_MODE.KID ? 'Kid Mode' : 'Adult Mode'}</div>
      </div>
      
      <div class="score-display">
        <span class="score-label">Score:</span>
        <span class="score-value">${gameState.score}</span>
      </div>
    `;
  }
  
  // Create question display
  const questionDisplay = document.createElement('div');
  questionDisplay.className = 'question-display';
  
  // Get difficulty class
  const difficultyClass = gameState.currentQuestion.difficulty.toLowerCase();
  
  questionDisplay.innerHTML = `
    <div class="difficulty-badge ${difficultyClass}">${gameState.currentQuestion.difficulty}</div>
    <div class="question-text">${gameState.currentQuestion.question}</div>
  `;
  
  // Create answer options
  const answerOptions = document.createElement('div');
  answerOptions.className = 'answer-options';
  
  if (gameState.currentQuestion.options) {
    // Multiple choice question
    gameState.currentQuestion.options.forEach((option, index) => {
      const letter = String.fromCharCode(65 + index); // A, B, C, D
      
      const optionButton = document.createElement('button');
      optionButton.className = 'answer-option';
      optionButton.dataset.answer = letter;
      
      optionButton.innerHTML = `
        <span class="option-letter">${letter}</span>
        <span class="option-text">${option}</span>
      `;
      
      optionButton.addEventListener('click', function() {
        submitAnswer(letter);
      });
      
      answerOptions.appendChild(optionButton);
    });
  }
  
  // Assemble the game screen
  gameScreen.appendChild(gameHeader);
  gameScreen.appendChild(questionDisplay);
  gameScreen.appendChild(answerOptions);
  
  gameContainer.appendChild(gameScreen);
}

// Render the answer result screen
function renderAnswerResult() {
  if (!gameState.answerResult || !gameState.currentQuestion) {
    console.error('No answer result available');
    return;
  }
  
  const resultScreen = document.createElement('div');
  resultScreen.className = 'result-screen';
  
  // Create result header
  const resultHeader = document.createElement('div');
  resultHeader.className = `result-header ${gameState.answerResult.isCorrect ? 'correct' : 'incorrect'}`;
  
  resultHeader.innerHTML = `
    <div class="result-icon">${gameState.answerResult.isCorrect ? '✓' : '✗'}</div>
    <div class="result-text">
      <h2>${gameState.answerResult.isCorrect ? 'Correct!' : 'Incorrect!'}</h2>
      ${gameState.answerResult.isCorrect ? 
        `<p>You earned ${gameState.answerResult.pointsAwarded} point${gameState.answerResult.pointsAwarded !== 1 ? 's' : ''}!</p>` : 
        `<p>The correct answer was: ${gameState.answerResult.correctAnswerText}</p>`
      }
    </div>
  `;
  
  // Create explanation
  const explanation = document.createElement('div');
  explanation.className = 'explanation';
  explanation.innerHTML = `
    <h3>Explanation:</h3>
    <p>${gameState.answerResult.explanation}</p>
  `;
  
  // Create next button
  const nextButton = document.createElement('button');
  nextButton.className = 'btn next-btn';
  nextButton.textContent = gameState.gameType === GAME_TYPE.MULTIPLAYER ? 'Next Player' : 'Next Question';
  
  nextButton.addEventListener('click', function() {
    getNextQuestion();
    renderGameState();
  });
  
  // Assemble the result screen
  resultScreen.appendChild(resultHeader);
  resultScreen.appendChild(explanation);
  resultScreen.appendChild(nextButton);
  
  gameContainer.appendChild(resultScreen);
}

// Render the round results screen (multiplayer only)
function renderRoundResults() {
  if (gameState.gameType !== GAME_TYPE.MULTIPLAYER) {
    return;
  }
  
  const roundResults = document.createElement('div');
  roundResults.className = 'round-results';
  
  // Find the round winner
  let highestScore = -1;
  let winnerIndex = -1;
  
  gameState.players.forEach((player, index) => {
    if (player.score > highestScore) {
      highestScore = player.score;
      winnerIndex = index;
    }
  });
  
  const roundWinner = winnerIndex >= 0 ? gameState.players[winnerIndex] : null;
  
  // Create round results content
  roundResults.innerHTML = `
    <h2>Round ${gameState.currentRound - 1} Results</h2>
    
    <div class="round-winner">
      <h3>${roundWinner ? `${roundWinner.name} wins this round!` : 'This round ended in a tie!'}</h3>
    </div>
    
    <div class="player-round-results">
      ${gameState.players.map(player => `
        <div class="player-round-result ${player.id === (roundWinner ? roundWinner.id : -1) ? 'winner' : ''}">
          <div class="player-name">${player.name}</div>
          <div class="player-round-score">Score: ${player.score}</div>
        </div>
      `).join('')}
    </div>
    
    <div class="series-status">
      <h3>Series Status:</h3>
      ${gameState.players.map(player => `
        <div class="player-series-status">
          <span class="player-name">${player.name}:</span>
          <span class="player-wins">${player.seriesWins} ${player.seriesWins === 1 ? 'win' : 'wins'}</span>
        </div>
      `).join('')}
    </div>
    
    <div class="round-buttons">
      <button class="btn next-round-btn">Start Round ${gameState.currentRound}</button>
    </div>
  `;
  
  // Add event listener for next round button
  roundResults.querySelector('.next-round-btn').addEventListener('click', function() {
    getNextQuestion();
    renderGameState();
  });
  
  gameContainer.appendChild(roundResults);
}

// Render the series results screen (multiplayer only)
function renderSeriesResults() {
  if (gameState.gameType !== GAME_TYPE.MULTIPLAYER) {
    return;
  }
  
  const seriesResults = document.createElement('div');
  seriesResults.className = 'series-results';
  
  // Get the series winner
  const seriesWinner = getSeriesWinner();
  
  // Generate the custom winner message
  const winnerMessage = seriesWinner ? getWinnerMessage(seriesWinner) : "The series ended in a tie!";
  
  // Create player results HTML
  let playersResultsHTML = '';
  gameState.players.forEach(player => {
    playersResultsHTML += `
      <div class="player-series-result ${player.id === (seriesWinner ? seriesWinner.id : -1) ? 'winner' : ''}">
        <div class="player-name">${player.name}</div>
        <div class="player-series-wins">Rounds Won: ${player.seriesWins}</div>
      </div>
    `;
  });
  
  seriesResults.innerHTML = `
    <h2>Series Results</h2>
    
    <div class="series-winner">
      <h3>${winnerMessage}</h3>
    </div>
    
    <div class="player-series-results">
      ${playersResultsHTML}
    </div>
    
    <div class="round-history">
      <h3>Round Winners:</h3>
      <ul>
        ${gameState.roundWinners.map((winnerID, index) => {
          const winner = gameState.players.find(player => player.id === winnerID);
          return `<li>Round ${index + 1}: ${winner ? winner.name : 'Tie'}</li>`;
        }).join('')}
      </ul>
    </div>
    
    <div class="series-buttons">
      <button class="btn new-series-btn">Play New Series</button>
      <button class="btn main-menu-btn">Main Menu</button>
    </div>
  `;
  
  // Add event listeners
  seriesResults.querySelector('.new-series-btn').addEventListener('click', function() {
    // Reset for a new series but keep the same players
    const playerData = gameState.players.map(player => ({
      name: player.name,
      age: player.age
    }));
    
    setupMultiplayerGame(playerData);
    getNextQuestion();
    renderGameState();
  });
  
  seriesResults.querySelector('.main-menu-btn').addEventListener('click', function() {
    resetGame();
    renderGameState();
  });
  
  gameContainer.appendChild(seriesResults);
}

// Render the game over screen (single player)
function renderGameOver() {
  const gameOver = document.createElement('div');
  gameOver.className = 'game-over';
  
  // Get performance feedback
  const feedback = getPerformanceFeedback(gameState.score);
  
  gameOver.innerHTML = `
    <h2>Game Over!</h2>
    
    <div class="final-score">
      <h3>Your Score: ${gameState.score}</h3>
    </div>
    
    <div class="performance-feedback">
      <p>${feedback}</p>
    </div>
    
    <div class="question-history">
      <h3>Question History:</h3>
      <ul>
        ${gameState.questionHistory.map((question, index) => `
          <li class="${question.isCorrect ? 'correct' : 'incorrect'}">
            <span class="question-number">${index + 1}.</span>
            <span class="question-text">${question.question}</span>
            <span class="result-icon">${question.isCorrect ? '✓' : '✗'}</span>
          </li>
        `).join('')}
      </ul>
    </div>
    
    <div class="game-over-buttons">
      <button class="btn play-again-btn">Play Again</button>
      <button class="btn main-menu-btn">Main Menu</button>
    </div>
  `;
  
  // Add event listeners
  gameOver.querySelector('.play-again-btn').addEventListener('click', function() {
    startNewGame();
    renderGameState();
  });
  
  gameOver.querySelector('.main-menu-btn').addEventListener('click', function() {
    resetGame();
    renderGameState();
  });
  
  gameContainer.appendChild(gameOver);
}

// Submit an answer
function submitAnswer(answer) {
  checkAnswer(answer);
  renderGameState();
}

// Helper function to get category name
function getCategoryName(categoryType) {
  switch (categoryType) {
    case CATEGORY_TYPE.FIELDING:
      return 'Baseball Fielding';
    case CATEGORY_TYPE.CURRENT:
      return 'Current Baseball';
    case CATEGORY_TYPE.BASKETBALL:
      return 'Basketball';
    case CATEGORY_TYPE.GEOGRAPHY:
      return 'Geography';
    case CATEGORY_TYPE.MATHEMATICS:
      return 'Mathematics';
    default:
      return 'Trivia';
  }
}
