// Enhanced Game Logic for Oh my Skibity Sigma
// This file contains the updated game logic to support multiplayer, age modes, and category selection

// Game state and constants
const GAME_STATUS = {
  WELCOME: 'welcome',
  SETUP_MULTIPLAYER: 'setup_multiplayer',
  PLAYING: 'playing',
  ANSWERED: 'answered',
  ROUND_END: 'round_end',
  SERIES_END: 'series_end',
  FINISHED: 'finished'
};

const DIFFICULTY = {
  EASY: 'easy',
  MEDIUM: 'medium',
  HARD: 'hard'
};

const DIFFICULTY_POINTS = {
  [DIFFICULTY.EASY]: 1,
  [DIFFICULTY.MEDIUM]: 2,
  [DIFFICULTY.HARD]: 3
};

const GAME_MODE = {
  ADULT: 'adult',
  KID: 'kid'
};

const CATEGORY_TYPE = {
  FIELDING: 'fielding',
  CURRENT: 'current'
};

const GAME_TYPE = {
  SINGLE: 'single',
  MULTIPLAYER: 'multiplayer'
};

// Game state object
let gameState = {
  // Basic game settings
  score: 0,
  currentDifficulty: DIFFICULTY.MEDIUM,
  currentQuestion: null,
  questionHistory: [],
  availableQuestions: [],
  gameStatus: GAME_STATUS.WELCOME,
  answerResult: null,
  
  // New features
  gameMode: GAME_MODE.KID,
  categoryType: CATEGORY_TYPE.FIELDING,
  gameType: GAME_TYPE.SINGLE,
  
  // Multiplayer specific
  players: [],
  currentPlayerIndex: 0,
  currentRound: 1,
  questionsPerRound: 10,
  questionCount: 0,
  roundWinners: []
};

// Initialize the game
function initializeGame() {
  resetGame();
  
  // Load saved preferences if available
  const savedMode = localStorage.getItem('skibitySigna_gameMode');
  if (savedMode && (savedMode === GAME_MODE.ADULT || savedMode === GAME_MODE.KID)) {
    gameState.gameMode = savedMode;
  }
  
  const savedCategory = localStorage.getItem('skibitySigna_categoryType');
  if (savedCategory && (savedCategory === CATEGORY_TYPE.FIELDING || savedCategory === CATEGORY_TYPE.CURRENT)) {
    gameState.categoryType = savedCategory;
  }
  
  return gameState;
}

// Reset the game state
function resetGame() {
  // Preserve preferences
  const gameMode = gameState.gameMode;
  const categoryType = gameState.categoryType;
  
  gameState = {
    // Basic game settings
    score: 0,
    currentDifficulty: DIFFICULTY.MEDIUM,
    currentQuestion: null,
    questionHistory: [],
    availableQuestions: [],
    gameStatus: GAME_STATUS.WELCOME,
    answerResult: null,
    
    // Preserved preferences
    gameMode: gameMode || GAME_MODE.KID,
    categoryType: categoryType || CATEGORY_TYPE.FIELDING,
    gameType: GAME_TYPE.SINGLE,
    
    // Multiplayer specific
    players: [],
    currentPlayerIndex: 0,
    currentRound: 1,
    questionsPerRound: 10,
    questionCount: 0,
    roundWinners: []
  };
  
  // Save preferences
  localStorage.setItem('skibitySigna_gameMode', gameState.gameMode);
  localStorage.setItem('skibitySigna_categoryType', gameState.categoryType);
  
  return gameState;
}

// Set game mode (adult/kid)
function setGameMode(mode) {
  if (mode !== GAME_MODE.ADULT && mode !== GAME_MODE.KID) {
    console.error('Invalid game mode');
    return gameState;
  }
  
  gameState.gameMode = mode;
  localStorage.setItem('skibitySigna_gameMode', mode);
  
  return gameState;
}

// Set category type (fielding/current)
function setCategoryType(category) {
  if (category !== CATEGORY_TYPE.FIELDING && category !== CATEGORY_TYPE.CURRENT) {
    console.error('Invalid category type');
    return gameState;
  }
  
  gameState.categoryType = category;
  localStorage.setItem('skibitySigna_categoryType', category);
  
  return gameState;
}

// Set game type (single/multiplayer)
function setGameType(type) {
  if (type !== GAME_TYPE.SINGLE && type !== GAME_TYPE.MULTIPLAYER) {
    console.error('Invalid game type');
    return gameState;
  }
  
  gameState.gameType = type;
  
  if (type === GAME_TYPE.MULTIPLAYER) {
    gameState.gameStatus = GAME_STATUS.SETUP_MULTIPLAYER;
  }
  
  return gameState;
}

// Set or change difficulty level
function setDifficulty(difficulty) {
  if (Object.values(DIFFICULTY).includes(difficulty)) {
    gameState.currentDifficulty = difficulty;
  }
  return gameState;
}

// Setup multiplayer game
function setupMultiplayerGame(playerNames) {
  if (!Array.isArray(playerNames) || playerNames.length < 2 || playerNames.length > 4) {
    console.error('Invalid player names. Need 2-4 players.');
    return gameState;
  }
  
  // Create player objects
  gameState.players = playerNames.map((name, index) => ({
    id: index + 1,
    name: name,
    score: 0,
    seriesWins: 0,
    isActive: index === 0 // First player starts
  }));
  
  gameState.currentPlayerIndex = 0;
  gameState.currentRound = 1;
  gameState.questionCount = 0;
  gameState.roundWinners = [];
  
  // Load questions for the round
  loadQuestionsForRound();
  
  return gameState;
}

// Load questions for the current round
function loadQuestionsForRound() {
  // Get questions based on current mode and category
  let allQuestions = [];
  
  if (gameState.categoryType === CATEGORY_TYPE.FIELDING) {
    // Use fielding scenarios
    if (gameState.gameMode === GAME_MODE.KID) {
      // For kids, use easy questions and some medium ones
      allQuestions = [
        ...scenarios.easy,
        ...scenarios.medium.filter((q, i) => i < 3) // Just a few medium ones
      ];
    } else {
      // For adults, use all difficulties
      allQuestions = [
        ...scenarios.easy,
        ...scenarios.medium,
        ...scenarios.hard
      ];
    }
  } else {
    // Use current baseball trivia
    allQuestions = currentBaseballTrivia[gameState.gameMode === GAME_MODE.KID ? 'kid' : 'adult'];
  }
  
  // Shuffle questions and select the required number
  shuffleArray(allQuestions);
  gameState.availableQuestions = allQuestions.slice(0, gameState.questionsPerRound);
  
  return gameState;
}

// Get the next question for the current player
function getNextQuestion() {
  // For multiplayer, check if we need to move to next round
  if (gameState.gameType === GAME_TYPE.MULTIPLAYER) {
    // If all questions for this round have been answered
    if (gameState.questionCount >= gameState.questionsPerRound) {
      return endRound();
    }
  }
  
  // Get the current question
  const questionIndex = gameState.gameType === GAME_TYPE.MULTIPLAYER ? 
    gameState.questionCount : 
    0; // In single player, always take the first question
  
  if (questionIndex >= gameState.availableQuestions.length) {
    // No more questions available
    gameState.gameStatus = gameState.gameType === GAME_TYPE.MULTIPLAYER ? 
      GAME_STATUS.ROUND_END : 
      GAME_STATUS.FINISHED;
    return gameState;
  }
  
  // Set the current question
  gameState.currentQuestion = gameState.availableQuestions[questionIndex];
  gameState.gameStatus = GAME_STATUS.PLAYING;
  gameState.answerResult = null;
  
  return gameState;
}

// Check answer and provide feedback
function checkAnswer(userAnswer) {
  if (!gameState.currentQuestion) {
    return gameState;
  }
  
  let isCorrect = false;
  let correctAnswerText = "";
  
  // Handle multiple choice answers (A, B, C, D format)
  if (gameState.currentQuestion.options) {
    // Convert letter answer to index (A->0, B->1, etc.)
    const letterToIndex = (letter) => letter.toUpperCase().charCodeAt(0) - 65;
    
    if (typeof userAnswer === 'string' && userAnswer.length === 1) {
      const answerIndex = letterToIndex(userAnswer);
      isCorrect = answerIndex === gameState.currentQuestion.correctAnswer;
      correctAnswerText = `${String.fromCharCode(65 + gameState.currentQuestion.correctAnswer)}) ${gameState.currentQuestion.options[gameState.currentQuestion.correctAnswer]}`;
    }
  } 
  
  // Calculate points awarded
  const pointsAwarded = isCorrect ? DIFFICULTY_POINTS[gameState.currentQuestion.difficulty] : 0;
  
  // Create answer result
  const answerResult = {
    isCorrect,
    correctAnswerText,
    explanation: gameState.currentQuestion.explanation,
    pointsAwarded
  };
  
  // Record question in history
  const answeredQuestion = {
    ...gameState.currentQuestion,
    userAnswer,
    isCorrect
  };
  
  // Update game state
  if (gameState.gameType === GAME_TYPE.SINGLE) {
    // Single player - update score directly
    gameState.score += pointsAwarded;
    gameState.questionHistory.push(answeredQuestion);
    
    // Remove the answered question from available questions
    gameState.availableQuestions.shift();
  } else {
    // Multiplayer - update current player's score
    const currentPlayer = gameState.players[gameState.currentPlayerIndex];
    currentPlayer.score += pointsAwarded;
    
    // If all players have answered this question, move to next question
    const nextPlayerIndex = (gameState.currentPlayerIndex + 1) % gameState.players.length;
    
    if (nextPlayerIndex === 0) {
      // All players have answered, move to next question
      gameState.questionCount++;
    }
    
    // Update active player
    gameState.players.forEach((player, index) => {
      player.isActive = index === nextPlayerIndex;
    });
    
    gameState.currentPlayerIndex = nextPlayerIndex;
  }
  
  gameState.gameStatus = GAME_STATUS.ANSWERED;
  gameState.answerResult = answerResult;
  
  return gameState;
}

// End the current round (multiplayer only)
function endRound() {
  if (gameState.gameType !== GAME_TYPE.MULTIPLAYER) {
    return gameState;
  }
  
  // Find the player with the highest score
  let highestScore = -1;
  let winnerIndex = -1;
  
  gameState.players.forEach((player, index) => {
    if (player.score > highestScore) {
      highestScore = player.score;
      winnerIndex = index;
    }
  });
  
  // In case of a tie, the first player with the highest score wins
  if (winnerIndex >= 0) {
    // Award a series win to the round winner
    gameState.players[winnerIndex].seriesWins++;
    gameState.roundWinners.push(gameState.players[winnerIndex].id);
  }
  
  // Check if the series is over (someone has 2 wins)
  const seriesOver = gameState.players.some(player => player.seriesWins >= 2);
  
  if (seriesOver || gameState.currentRound >= 3) {
    // Series is complete
    gameState.gameStatus = GAME_STATUS.SERIES_END;
  } else {
    // Prepare for next round
    gameState.currentRound++;
    gameState.questionCount = 0;
    
    // Reset player scores for the new round
    gameState.players.forEach(player => {
      player.score = 0;
      player.isActive = player.id === 1; // First player starts again
    });
    
    gameState.currentPlayerIndex = 0;
    
    // Load new questions for the next round
    loadQuestionsForRound();
    
    gameState.gameStatus = GAME_STATUS.ROUND_END;
  }
  
  return gameState;
}

// Get performance feedback based on score and game mode
function getPerformanceFeedback(score) {
  if (gameState.gameMode === GAME_MODE.KID) {
    if (score === 0) {
      return "Keep practicing! Everyone starts somewhere in learning baseball!";
    } else if (score < 5) {
      return "Good job! You're learning about baseball and that's awesome!";
    } else if (score < 10) {
      return "Wow! You really know your baseball stuff! That's impressive!";
    } else if (score < 15) {
      return "Amazing! You could teach others about baseball with all that knowledge!";
    } else {
      return "INCREDIBLE! You're a baseball genius! Maybe you'll be a coach someday!";
    }
  } else {
    // Adult feedback
    if (score === 0) {
      return "Keep practicing! Baseball fielding decisions require experience.";
    } else if (score < 5) {
      return "Good start! You're developing your baseball IQ.";
    } else if (score < 10) {
      return "Solid performance! You know your way around the diamond.";
    } else if (score < 15) {
      return "Excellent! You could be a field manager with that baseball knowledge.";
    } else {
      return "Outstanding! You have professional-level understanding of baseball strategy!";
    }
  }
}

// Get the series winner (multiplayer only)
function getSeriesWinner() {
  if (gameState.gameType !== GAME_TYPE.MULTIPLAYER) {
    return null;
  }
  
  // Find the player with the most series wins
  let mostWins = -1;
  let winnerIndex = -1;
  
  gameState.players.forEach((player, index) => {
    if (player.seriesWins > mostWins) {
      mostWins = player.seriesWins;
      winnerIndex = index;
    }
  });
  
  return winnerIndex >= 0 ? gameState.players[winnerIndex] : null;
}

// Start a new game
function startNewGame() {
  if (gameState.gameType === GAME_TYPE.SINGLE) {
    // Single player game
    resetGame();
    
    // Load questions based on current settings
    if (gameState.categoryType === CATEGORY_TYPE.FIELDING) {
      // Use fielding scenarios
      gameState.availableQuestions = {
        [DIFFICULTY.EASY]: [...scenarios.easy],
        [DIFFICULTY.MEDIUM]: [...scenarios.medium],
        [DIFFICULTY.HARD]: [...scenarios.hard]
      };
      
      // Shuffle the scenarios for each difficulty
      shuffleArray(gameState.availableQuestions[DIFFICULTY.EASY]);
      shuffleArray(gameState.availableQuestions[DIFFICULTY.MEDIUM]);
      shuffleArray(gameState.availableQuestions[DIFFICULTY.HARD]);
    } else {
      // Use current baseball trivia
      const trivia = currentBaseballTrivia[gameState.gameMode === GAME_MODE.KID ? 'kid' : 'adult'];
      shuffleArray(trivia);
      gameState.availableQuestions = trivia;
    }
    
    getNextQuestion();
  } else {
    // For multiplayer, move to player setup
    gameState.gameStatus = GAME_STATUS.SETUP_MULTIPLAYER;
  }
  
  return gameState;
}

// Utility function to shuffle an array (Fisher-Yates algorithm)
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}
