// Mathematics Trivia Questions
// This file contains mathematics trivia questions for the "Oh my Skibity Sigma" game

const mathTrivia = {
  child: [
    {
      id: "math_c1",
      question: "What is 5 + 7?",
      options: [
        "10",
        "11",
        "12",
        "13"
      ],
      correctAnswer: 2, // C - 12
      explanation: "5 + 7 = 12. You can count 5 fingers on one hand and 7 on the other to get 12 total!",
      difficulty: "easy"
    },
    {
      id: "math_c2",
      question: "How many sides does a triangle have?",
      options: [
        "2",
        "3",
        "4",
        "5"
      ],
      correctAnswer: 1, // B - 3
      explanation: "A triangle has 3 sides. That's why it's called a 'tri-angle' - 'tri' means three!",
      difficulty: "easy"
    },
    {
      id: "math_c3",
      question: "What is 10 - 4?",
      options: [
        "4",
        "5",
        "6",
        "7"
      ],
      correctAnswer: 2, // C - 6
      explanation: "10 - 4 = 6. If you have 10 apples and give away 4, you'll have 6 apples left.",
      difficulty: "easy"
    },
    {
      id: "math_c4",
      question: "What is double 7?",
      options: [
        "12",
        "14",
        "16",
        "18"
      ],
      correctAnswer: 1, // B - 14
      explanation: "Double 7 means 7 + 7 or 7 × 2, which equals 14.",
      difficulty: "easy"
    },
    {
      id: "math_c5",
      question: "How many minutes are in 1 hour?",
      options: [
        "30",
        "45",
        "60",
        "100"
      ],
      correctAnswer: 2, // C - 60
      explanation: "There are 60 minutes in 1 hour. That's why the minute hand on a clock goes all the way around once every hour!",
      difficulty: "easy"
    },
    {
      id: "math_c6",
      question: "What is 3 × 4?",
      options: [
        "7",
        "10",
        "12",
        "15"
      ],
      correctAnswer: 2, // C - 12
      explanation: "3 × 4 = 12. This means 3 groups of 4, so 4 + 4 + 4 = 12.",
      difficulty: "easy"
    },
    {
      id: "math_c7",
      question: "What shape has 4 equal sides and 4 equal angles?",
      options: [
        "Rectangle",
        "Triangle",
        "Square",
        "Circle"
      ],
      correctAnswer: 2, // C - Square
      explanation: "A square has 4 equal sides and 4 equal angles (90° each). A rectangle has 4 angles of 90° but its sides aren't all equal.",
      difficulty: "easy"
    },
    {
      id: "math_c8",
      question: "What is half of 16?",
      options: [
        "4",
        "6",
        "8",
        "10"
      ],
      correctAnswer: 2, // C - 8
      explanation: "Half of 16 is 8. You can think of it as dividing 16 by 2, or splitting 16 things into two equal groups.",
      difficulty: "easy"
    },
    {
      id: "math_c9",
      question: "If you have 3 cookies and get 5 more, how many do you have?",
      options: [
        "7",
        "8",
        "9",
        "10"
      ],
      correctAnswer: 1, // B - 8
      explanation: "If you have 3 cookies and get 5 more, you'll have 3 + 5 = 8 cookies total.",
      difficulty: "easy"
    },
    {
      id: "math_c10",
      question: "What number comes next: 2, 4, 6, 8, ...?",
      options: [
        "9",
        "10",
        "11",
        "12"
      ],
      correctAnswer: 1, // B - 10
      explanation: "The pattern is counting by 2s (adding 2 each time). After 8, the next number would be 8 + 2 = 10.",
      difficulty: "easy"
    },
    {
      id: "math_c11",
      question: "How many days are in a week?",
      options: [
        "5",
        "6",
        "7",
        "8"
      ],
      correctAnswer: 2, // C - 7
      explanation: "There are 7 days in a week: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, and Sunday.",
      difficulty: "easy"
    },
    {
      id: "math_c12",
      question: "What is 20 ÷ 4?",
      options: [
        "4",
        "5",
        "6",
        "8"
      ],
      correctAnswer: 1, // B - 5
      explanation: "20 ÷ 4 = 5. This means if you divide 20 items into 4 equal groups, each group will have 5 items.",
      difficulty: "medium"
    },
    {
      id: "math_c13",
      question: "What is 9 + 8?",
      options: [
        "15",
        "16",
        "17",
        "18"
      ],
      correctAnswer: 2, // C - 17
      explanation: "9 + 8 = 17. One way to solve this is to make 10 first: 9 + 1 = 10, then add the remaining 7 to get 17.",
      difficulty: "easy"
    },
    {
      id: "math_c14",
      question: "How many corners does a cube have?",
      options: [
        "4",
        "6",
        "8",
        "12"
      ],
      correctAnswer: 2, // C - 8
      explanation: "A cube has 8 corners (or vertices). You can count them on a dice, which is shaped like a cube!",
      difficulty: "medium"
    },
    {
      id: "math_c15",
      question: "What is 5 × 5?",
      options: [
        "20",
        "25",
        "30",
        "35"
      ],
      correctAnswer: 1, // B - 25
      explanation: "5 × 5 = 25. This is also written as 5², which means 5 squared.",
      difficulty: "medium"
    }
  ],
  
  preteen: [
    {
      id: "math_p1",
      question: "What is the area of a rectangle with length 7 cm and width 4 cm?",
      options: [
        "11 cm²",
        "22 cm²",
        "28 cm²",
        "30 cm²"
      ],
      correctAnswer: 2, // C - 28 cm²
      explanation: "The area of a rectangle is length × width. So 7 cm × 4 cm = 28 square centimeters (cm²).",
      difficulty: "medium"
    },
    {
      id: "math_p2",
      question: "What is 3/4 of 20?",
      options: [
        "12",
        "15",
        "16",
        "18"
      ],
      correctAnswer: 1, // B - 15
      explanation: "To find 3/4 of 20, multiply: 3/4 × 20 = 3 × 20 ÷ 4 = 60 ÷ 4 = 15.",
      difficulty: "medium"
    },
    {
      id: "math_p3",
      question: "If a recipe calls for 2/3 cup of flour and you want to make 1/2 of the recipe, how much flour do you need?",
      options: [
        "1/3 cup",
        "1/6 cup",
        "1/4 cup",
        "1/2 cup"
      ],
      correctAnswer: 0, // A - 1/3 cup
      explanation: "To find 1/2 of 2/3 cup, multiply: 1/2 × 2/3 = 2/6 = 1/3 cup of flour.",
      difficulty: "medium"
    },
    {
      id: "math_p4",
      question: "What is the perimeter of a square with sides of length 5 cm?",
      options: [
        "10 cm",
        "15 cm",
        "20 cm",
        "25 cm"
      ],
      correctAnswer: 2, // C - 20 cm
      explanation: "The perimeter of a square is 4 × side length. So 4 × 5 cm = 20 cm.",
      difficulty: "medium"
    },
    {
      id: "math_p5",
      question: "What is the value of 2³?",
      options: [
        "6",
        "8",
        "9",
        "16"
      ],
      correctAnswer: 1, // B - 8
      explanation: "2³ means 2 × 2 × 2 = 8. The exponent (3) tells you how many times to multiply the base number (2) by itself.",
      difficulty: "medium"
    },
    {
      id: "math_p6",
      question: "What is the next number in the sequence: 1, 1, 2, 3, 5, 8, ...?",
      options: [
        "11",
        "12",
        "13",
        "15"
      ],
      correctAnswer: 2, // C - 13
      explanation: "This is the Fibonacci sequence, where each number is the sum of the two previous numbers. 5 + 8 = 13, so 13 is next.",
      difficulty: "medium"
    },
    {
      id: "math_p7",
      question: "If a shirt costs $24 and is on sale for 25% off, what is the sale price?",
      options: [
        "$6",
        "$12",
        "$18",
        "$21"
      ],
      correctAnswer: 2, // C - $18
      explanation: "25% of $24 is $24 × 0.25 = $6. The sale price is $24 - $6 = $18.",
      difficulty: "medium"
    },
    {
      id: "math_p8",
      question: "What is the average (mean) of 12, 15, 18, and 23?",
      options: [
        "15",
        "16",
        "17",
        "18"
      ],
      correctAnswer: 2, // C - 17
      explanation: "To find the average, add all numbers and divide by how many there are: (12 + 15 + 18 + 23) ÷ 4 = 68 ÷ 4 = 17.",
      difficulty: "medium"
    },
    {
      id: "math_p9",
      question: "What is the prime factorization of 36?",
      options: [
        "2 × 18",
        "4 × 9",
        "6 × 6",
        "2² × 3²"
      ],
      correctAnswer: 3, // D - 2² × 3²
      explanation: "The prime factorization uses only prime numbers. 36 = 2 × 2 × 3 × 3 = 2² × 3².",
      difficulty: "hard"
    },
    {
      id: "math_p10",
      question: "If a car travels at 60 miles per hour, how far will it travel in 2.5 hours?",
      options: [
        "120 miles",
        "150 miles",
        "180 miles",
        "200 miles"
      ],
      correctAnswer: 1, // B - 150 miles
      explanation: "Distance = Speed × Time. So 60 miles per hour × 2.5 hours = 150 miles.",
      difficulty: "medium"
    },
    {
      id: "math_p11",
      question: "What is the value of x in the equation 3x + 7 = 22?",
      options: [
        "3",
        "5",
        "7",
        "9"
      ],
      correctAnswer: 1, // B - 5
      explanation: "To solve for x: 3x + 7 = 22, subtract 7 from both sides: 3x = 15, then divide both sides by 3: x = 5.",
      difficulty: "medium"
    },
    {
      id: "math_p12",
      question: "What is the area of a triangle with base 8 cm and height 6 cm?",
      options: [
        "14 cm²",
        "24 cm²",
        "30 cm²",
        "48 cm²"
      ],
      correctAnswer: 1, // B - 24 cm²
      explanation: "The area of a triangle is (base × height) ÷ 2. So (8 cm × 6 cm) ÷ 2 = 48 ÷ 2 = 24 cm².",
      difficulty: "medium"
    },
    {
      id: "math_p13",
      question: "What is 20% of 85?",
      options: [
        "8.5",
        "17",
        "20",
        "25"
      ],
      correctAnswer: 1, // B - 17
      explanation: "To find 20% of 85, multiply: 85 × 0.20 = 17.",
      difficulty: "medium"
    },
    {
      id: "math_p14",
      question: "If 3 pencils cost $0.75, how much do 12 pencils cost?",
      options: [
        "$2.25",
        "$3.00",
        "$3.25",
        "$3.75"
      ],
      correctAnswer: 0, // A - $2.25
      explanation: "If 3 pencils cost $0.75, then 1 pencil costs $0.75 ÷ 3 = $0.25. So 12 pencils cost 12 × $0.25 = $3.00.",
      difficulty: "medium"
    },
    {
      id: "math_p15",
      question: "What is the greatest common factor (GCF) of 24 and 36?",
      options: [
        "6",
        "9",
        "12",
        "18"
      ],
      correctAnswer: 2, // C - 12
      explanation: "The factors of 24 are 1, 2, 3, 4, 6, 8, 12, 24. The factors of 36 are 1, 2, 3, 4, 6, 9, 12, 18, 36. The greatest common factor is 12.",
      difficulty: "hard"
    }
  ],
  
  teen: [
    {
      id: "math_t1",
      question: "Solve for x: 2x - 5 = 3x + 7",
      options: [
        "x = -12",
        "x = -2",
        "x = 2",
        "x = 12"
      ],
      correctAnswer: 0, // A - x = -12
      explanation: "2x - 5 = 3x + 7\n2x - 3x = 7 + 5\n-x = 12\nx = -12",
      difficulty: "medium"
    },
    {
      id: "math_t2",
      question: "What is the slope of a line passing through the points (2, 3) and (6, 11)?",
      options: [
        "1",
        "2",
        "3",
        "4"
      ],
      correctAnswer: 1, // B - 2
      explanation: "The slope formula is (y₂ - y₁) ÷ (x₂ - x₁). Using the points (2, 3) and (6, 11):\nSlope = (11 - 3) ÷ (6 - 2) = 8 ÷ 4 = 2.",
      difficulty: "medium"
    },
    {
      id: "math_t3",
      question: "What is the value of √144?",
      options: [
        "12",
        "14",
        "24",
        "72"
      ],
      correctAnswer: 0, // A - 12
      explanation: "√144 means the square root of 144, which is 12 because 12² = 12 × 12 = 144.",
      difficulty: "medium"
    },
    {
      id: "math_t4",
      question: "If f(x) = 3x² - 2x + 5, what is f(2)?",
      options: [
        "9",
        "13",
        "15",
        "17"
      ],
      correctAnswer: 2, // C - 15
      explanation: "f(2) = 3(2)² - 2(2) + 5 = 3(4) - 4 + 5 = 12 - 4 + 5 = 13.",
      difficulty: "medium"
    },
    {
      id: "math_t5",
      question: "What is the value of sin(90°)?",
      options: [
        "0",
        "1",
        "√2/2",
        "undefined"
      ],
      correctAnswer: 1, // B - 1
      explanation: "sin(90°) = 1. This is one of the special angles in trigonometry that's important to memorize.",
      difficulty: "medium"
    },
    {
      id: "math_t6",
      question: "What is the solution to the inequality 3x - 7 > 5?",
      options: [
        "x > 4",
        "x > 12/3",
        "x < 4",
        "x < 12/3"
      ],
      correctAnswer: 0, // A - x > 4
      explanation: "3x - 7 > 5\n3x > 12\nx > 4",
      difficulty: "medium"
    },
    {
      id: "math_t7",
      question: "What is the area of a circle with radius 5 cm?",
      options: [
        "10π cm²",
        "25π cm²",
        "50π cm²",
        "100π cm²"
      ],
      correctAnswer: 1, // B - 25π cm²
      explanation: "The area of a circle is πr². So π(5)² = 25π cm².",
      difficulty: "medium"
    },
    {
      id: "math_t8",
      question: "What is the value of log₁₀(100)?",
      options: [
        "1",
        "2",
        "10",
        "100"
      ],
      correctAnswer: 1, // B - 2
      explanation: "log₁₀(100) = 2 because 10² = 100. The logarithm (base 10) of a number is the exponent to which 10 must be raised to get that number.",
      difficulty: "hard"
    },
    {
      id: "math_t9",
      question: "What is the value of 5! (5 factorial)?",
      options: [
        "25",
        "60",
        "120",
        "720"
      ],
      correctAnswer: 2, // C - 120
      explanation: "5! = 5 × 4 × 3 × 2 × 1 = 120. Factorial means to multiply a number by all positive integers less than it.",
      difficulty: "medium"
    },
    {
      id: "math_t10",
      question: "What is the equation of a line with slope 3 passing through the point (2, 5)?",
      options: [
        "y = 3x - 1",
        "y = 3x - 6",
        "y = 3x + 1",
        "y = 3x - 3"
      ],
      correctAnswer: 0, // A - y = 3x - 1
      explanation: "Using the point-slope form: y - y₁ = m(x - x₁)\ny - 5 = 3(x - 2)\ny - 5 = 3x - 6\ny = 3x - 6 + 5\ny = 3x - 1",
      difficulty: "hard"
    },
    {
      id: "math_t11",
      question: "What is the value of cos(0°)?",
      options: [
        "0",
        "1",
        "√2/2",
        "undefined"
      ],
      correctAnswer: 1, // B - 1
      explanation: "cos(0°) = 1. This is one of the special angles in trigonometry that's important to memorize.",
      difficulty: "medium"
    },
    {
      id: "math_t12",
      question: "What is the solution to the system of equations: 2x + y = 7 and x - y = 1?",
      options: [
        "x = 2, y = 3",
        "x = 3, y = 1",
        "x = 4, y = -1",
        "x = 1, y = 5"
      ],
      correctAnswer: 0, // A - x = 2, y = 3
      explanation: "From x - y = 1, we get y = x - 1. Substituting into 2x + y = 7:\n2x + (x - 1) = 7\n3x - 1 = 7\n3x = 8\nx = 8/3\nThen y = x - 1 = 8/3 - 1 = 5/3\nSo x = 8/3 and y = 5/3.",
      difficulty: "hard"
    },
    {
      id: "math_t13",
      question: "What is the volume of a cube with side length 4 cm?",
      options: [
        "16 cm³",
        "32 cm³",
        "48 cm³",
        "64 cm³"
      ],
      correctAnswer: 3, // D - 64 cm³
      explanation: "The volume of a cube is (side length)³. So (4 cm)³ = 64 cm³.",
      difficulty: "medium"
    },
    {
      id: "math_t14",
      question: "What is the value of tan(45°)?",
      options: [
        "0",
        "1",
        "√2",
        "√3"
      ],
      correctAnswer: 1, // B - 1
      explanation: "tan(45°) = 1. This is one of the special angles in trigonometry that's important to memorize. tan(θ) = sin(θ)/cos(θ), and at 45°, sin and cos are both √2/2, so their ratio is 1.",
      difficulty: "medium"
    },
    {
      id: "math_t15",
      question: "What is the quadratic formula for solving ax² + bx + c = 0?",
      options: [
        "x = (-b ± √(b² - 4ac))/2a",
        "x = (-b ± √(b² + 4ac))/2a",
        "x = (b ± √(b² - 4ac))/2a",
        "x = (-b ± √(4ac - b²))/2a"
      ],
      correctAnswer: 0, // A - x = (-b ± √(b² - 4ac))/2a
      explanation: "The quadratic formula is x = (-b ± √(b² - 4ac))/2a. It's used to find the solutions (roots) of any quadratic equation in the form ax² + bx + c = 0.",
      difficulty: "hard"
    }
  ],
  
  adult: [
    {
      id: "math_a1",
      question: "What is the derivative of f(x) = x³ - 4x² + 2x - 7?",
      options: [
        "f'(x) = 3x² - 8x + 2",
        "f'(x) = 3x² - 4x + 2",
        "f'(x) = 3x² - 8x - 7",
        "f'(x) = x² - 8x + 2"
      ],
      correctAnswer: 0, // A - f'(x) = 3x² - 8x + 2
      explanation: "To find the derivative, apply the power rule to each term: d/dx(x^n) = nx^(n-1).\nf'(x) = d/dx(x³) - d/dx(4x²) + d/dx(2x) - d/dx(7)\nf'(x) = 3x² - 8x + 2 - 0\nf'(x) = 3x² - 8x + 2",
      difficulty: "hard"
    },
    {
      id: "math_a2",
      question: "What is the value of ∫₀¹ (2x + 3) dx?",
      options: [
        "2.5",
        "4",
        "5",
        "6"
      ],
      correctAnswer: 1, // B - 4
      explanation: "∫₀¹ (2x + 3) dx = [x² + 3x]₀¹ = (1² + 3(1)) - (0² + 3(0)) = 1 + 3 - 0 = 4",
      difficulty: "hard"
    },
    {
      id: "math_a3",
      question: "What is the solution to the equation e^x = 10?",
      options: [
        "x = ln(10)",
        "x = log₁₀(e)",
        "x = 10e",
        "x = e^10"
      ],
      correctAnswer: 0, // A - x = ln(10)
      explanation: "To solve e^x = 10, take the natural logarithm of both sides:\nln(e^x) = ln(10)\nx = ln(10) ≈ 2.303",
      difficulty: "hard"
    },
    {
      id: "math_a4",
      question: "What is the limit as x approaches 0 of (sin x)/x?",
      options: [
        "0",
        "1",
        "∞",
        "undefined"
      ],
      correctAnswer: 1, // B - 1
      explanation: "The limit as x approaches 0 of (sin x)/x = 1. This is a fundamental limit in calculus that can be proven using the squeeze theorem or by using L'Hôpital's rule.",
      difficulty: "hard"
    },
    {
      id: "math_a5",
      question: "What is the value of cos(π)?",
      options: [
        "-1",
        "0",
        "1",
        "undefined"
      ],
      correctAnswer: 0, // A - -1
      explanation: "cos(π) = -1. This is because π radians equals 180°, and cos(180°) = -1.",
      difficulty: "hard"
    },
    {
      id: "math_a6",
      question: "What is the sum of the infinite geometric series 1 + 1/2 + 1/4 + 1/8 + ...?",
      options: [
        "1",
        "2",
        "4",
        "∞"
      ],
      correctAnswer: 1, // B - 2
      explanation: "This is an infinite geometric series with first term a = 1 and common ratio r = 1/2. The sum of such a series is a/(1-r) = 1/(1-1/2) = 1/(1/2) = 2.",
      difficulty: "hard"
    },
    {
      id: "math_a7",
      question: "What is the value of i² where i is the imaginary unit?",
      options: [
        "-1",
        "0",
        "1",
        "i"
      ],
      correctAnswer: 0, // A - -1
      explanation: "i² = -1. This is the defining property of the imaginary unit i, which is defined as the square root of -1.",
      difficulty: "hard"
    },
    {
      id: "math_a8",
      question: "What is the determinant of the matrix [[3, 1], [2, 4]]?",
      options: [
        "5",
        "10",
        "12",
        "14"
      ],
      correctAnswer: 1, // B - 10
      explanation: "For a 2×2 matrix [[a, b], [c, d]], the determinant is ad - bc. So for [[3, 1], [2, 4]], the determinant is 3(4) - 1(2) = 12 - 2 = 10.",
      difficulty: "hard"
    },
    {
      id: "math_a9",
      question: "What is the value of ∑ᵢ₌₁⁵ i²?",
      options: [
        "30",
        "55",
        "65",
        "225"
      ],
      correctAnswer: 2, // C - 55
      explanation: "∑ᵢ₌₁⁵ i² = 1² + 2² + 3² + 4² + 5² = 1 + 4 + 9 + 16 + 25 = 55. There's also a formula for this: ∑ᵢ₌₁ⁿ i² = n(n+1)(2n+1)/6, which gives 5(6)(11)/6 = 55.",
      difficulty: "hard"
    },
    {
      id: "math_a10",
      question: "What is the solution to the differential equation dy/dx = 2x with y(0) = 3?",
      options: [
        "y = x² + 3",
        "y = 2x + 3",
        "y = x² - 3",
        "y = 2x² + 3"
      ],
      correctAnswer: 0, // A - y = x² + 3
      explanation: "To solve dy/dx = 2x, integrate both sides: y = ∫2x dx = x² + C. Using the initial condition y(0) = 3, we get 3 = 0² + C, so C = 3. Therefore, y = x² + 3.",
      difficulty: "hard"
    },
    {
      id: "math_a11",
      question: "What is the value of sin(π/2)?",
      options: [
        "-1",
        "0",
        "1",
        "undefined"
      ],
      correctAnswer: 2, // C - 1
      explanation: "sin(π/2) = 1. This is because π/2 radians equals 90°, and sin(90°) = 1.",
      difficulty: "hard"
    },
    {
      id: "math_a12",
      question: "What is the probability of getting exactly 2 heads in 5 fair coin tosses?",
      options: [
        "5/32",
        "10/32",
        "15/32",
        "1/4"
      ],
      correctAnswer: 1, // B - 10/32
      explanation: "This follows a binomial distribution: P(X=k) = (n choose k) p^k (1-p)^(n-k). Here, n=5, k=2, p=1/2.\nP(X=2) = (5 choose 2) (1/2)^2 (1/2)^3 = 10 × (1/4) × (1/8) = 10/32 = 5/16.",
      difficulty: "hard"
    },
    {
      id: "math_a13",
      question: "What is the value of log₂(32)?",
      options: [
        "4",
        "5",
        "6",
        "8"
      ],
      correctAnswer: 1, // B - 5
      explanation: "log₂(32) = 5 because 2^5 = 32. The logarithm (base 2) of a number is the exponent to which 2 must be raised to get that number.",
      difficulty: "hard"
    },
    {
      id: "math_a14",
      question: "What is the value of ∫₀^π sin(x) dx?",
      options: [
        "0",
        "1",
        "2",
        "π"
      ],
      correctAnswer: 2, // C - 2
      explanation: "∫₀^π sin(x) dx = [-cos(x)]₀^π = -cos(π) - (-cos(0)) = -(-1) - (-1) = 1 + 1 = 2",
      difficulty: "hard"
    },
    {
      id: "math_a15",
      question: "What is the value of the complex number (3 + 4i) × (2 - 3i)?",
      options: [
        "6 + i",
        "6 - i",
        "18 + i",
        "18 - i"
      ],
      correctAnswer: 0, // A - 18 + i
      explanation: "(3 + 4i) × (2 - 3i) = 6 - 9i + 8i - 12i² = 6 - i - 12(-1) = 6 - i + 12 = 18 - i",
      difficulty: "hard"
    }
  ]
};
