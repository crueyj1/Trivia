// Geography Trivia Questions
// This file contains geography trivia questions for the "Oh my Skibity Sigma" game

const geographyTrivia = {
  child: [
    {
      id: "geo_c1",
      question: "Which country is shaped like a boot?",
      options: [
        "France",
        "Italy",
        "Spain",
        "Germany"
      ],
      correctAnswer: 1, // B - Italy
      explanation: "Italy is shaped like a boot! If you look at a map, you can see that Italy looks like a boot kicking a ball (Sicily).",
      difficulty: "easy"
    },
    {
      id: "geo_c2",
      question: "What is the largest ocean on Earth?",
      options: [
        "Atlantic Ocean",
        "Indian Ocean",
        "Arctic Ocean",
        "Pacific Ocean"
      ],
      correctAnswer: 3, // D - Pacific Ocean
      explanation: "The Pacific Ocean is the largest and deepest ocean on Earth. It covers more than 30% of the Earth's surface!",
      difficulty: "easy"
    },
    {
      id: "geo_c3",
      question: "Which of these is NOT a continent?",
      options: [
        "Europe",
        "Africa",
        "Australia",
        "Hawaii"
      ],
      correctAnswer: 3, // D - Hawaii
      explanation: "Hawaii is not a continent - it's a state of the United States and a group of islands in the Pacific Ocean. The seven continents are: North America, South America, Europe, Asia, Africa, Australia, and Antarctica.",
      difficulty: "easy"
    },
    {
      id: "geo_c4",
      question: "What is the capital city of the United States?",
      options: [
        "New York City",
        "Washington, D.C.",
        "Los Angeles",
        "Chicago"
      ],
      correctAnswer: 1, // B - Washington, D.C.
      explanation: "Washington, D.C. is the capital city of the United States. D.C. stands for 'District of Columbia'. The White House, where the President lives, is located there!",
      difficulty: "easy"
    },
    {
      id: "geo_c5",
      question: "Which of these animals would you find in Antarctica?",
      options: [
        "Polar bears",
        "Penguins",
        "Tigers",
        "Monkeys"
      ],
      correctAnswer: 1, // B - Penguins
      explanation: "Penguins live in Antarctica! Interestingly, polar bears live only in the Arctic (North Pole) region, not in Antarctica (South Pole).",
      difficulty: "easy"
    },
    {
      id: "geo_c6",
      question: "Which country is home to the Great Pyramid of Giza?",
      options: [
        "Mexico",
        "Egypt",
        "China",
        "Greece"
      ],
      correctAnswer: 1, // B - Egypt
      explanation: "The Great Pyramid of Giza is in Egypt. It was built over 4,500 years ago and is one of the Seven Wonders of the Ancient World!",
      difficulty: "easy"
    },
    {
      id: "geo_c7",
      question: "What is the largest country in the world by land area?",
      options: [
        "China",
        "United States",
        "Russia",
        "Canada"
      ],
      correctAnswer: 2, // C - Russia
      explanation: "Russia is the largest country in the world by land area. It spans across Eastern Europe and Northern Asia and covers about 1/8 of the Earth's inhabited land area!",
      difficulty: "medium"
    },
    {
      id: "geo_c8",
      question: "Which of these is NOT a real country?",
      options: [
        "Madagascar",
        "Wakanda",
        "Iceland",
        "New Zealand"
      ],
      correctAnswer: 1, // B - Wakanda
      explanation: "Wakanda is not a real country - it's a fictional country from Marvel comics and movies like Black Panther. The other three are real countries!",
      difficulty: "easy"
    },
    {
      id: "geo_c9",
      question: "Which mountain is the tallest in the world?",
      options: [
        "Mount Kilimanjaro",
        "Mount Everest",
        "Mount Fuji",
        "Mount McKinley (Denali)"
      ],
      correctAnswer: 1, // B - Mount Everest
      explanation: "Mount Everest is the tallest mountain in the world, standing at 29,032 feet (8,849 meters) above sea level. It's located in the Himalayan mountain range on the border between Nepal and Tibet.",
      difficulty: "easy"
    },
    {
      id: "geo_c10",
      question: "Which of these countries is an island?",
      options: [
        "Mexico",
        "Japan",
        "France",
        "Brazil"
      ],
      correctAnswer: 1, // B - Japan
      explanation: "Japan is an island country located in East Asia. It consists of four main islands (Honshu, Hokkaido, Kyushu, and Shikoku) and thousands of smaller islands!",
      difficulty: "easy"
    },
    {
      id: "geo_c11",
      question: "What is the capital city of France?",
      options: [
        "London",
        "Berlin",
        "Paris",
        "Rome"
      ],
      correctAnswer: 2, // C - Paris
      explanation: "Paris is the capital city of France. It's famous for landmarks like the Eiffel Tower, the Louvre Museum, and Notre-Dame Cathedral!",
      difficulty: "easy"
    },
    {
      id: "geo_c12",
      question: "Which of these is a desert?",
      options: [
        "Amazon",
        "Sahara",
        "Mississippi",
        "Alps"
      ],
      correctAnswer: 1, // B - Sahara
      explanation: "The Sahara is a desert - in fact, it's the largest hot desert in the world! The Amazon is a rainforest, the Mississippi is a river, and the Alps are mountains.",
      difficulty: "easy"
    },
    {
      id: "geo_c13",
      question: "Which country is known for kangaroos and koalas?",
      options: [
        "South Africa",
        "Brazil",
        "Australia",
        "India"
      ],
      correctAnswer: 2, // C - Australia
      explanation: "Australia is home to kangaroos and koalas! These animals are native to Australia and are symbols of the country.",
      difficulty: "easy"
    },
    {
      id: "geo_c14",
      question: "What is the capital city of Canada?",
      options: [
        "Toronto",
        "Vancouver",
        "Montreal",
        "Ottawa"
      ],
      correctAnswer: 3, // D - Ottawa
      explanation: "Ottawa is the capital city of Canada. Many people think it's Toronto because that's Canada's largest city, but the capital is actually Ottawa!",
      difficulty: "medium"
    },
    {
      id: "geo_c15",
      question: "Which of these is NOT a state in the United States?",
      options: [
        "California",
        "Florida",
        "Toronto",
        "Texas"
      ],
      correctAnswer: 2, // C - Toronto
      explanation: "Toronto is not a state - it's a city in Canada! California, Florida, and Texas are all states in the United States.",
      difficulty: "easy"
    }
  ],
  
  preteen: [
    {
      id: "geo_p1",
      question: "Which of these countries is located in South America?",
      options: [
        "Spain",
        "Mexico",
        "Brazil",
        "Egypt"
      ],
      correctAnswer: 2, // C - Brazil
      explanation: "Brazil is located in South America. It's the largest country in South America, both by land area and population, and is famous for the Amazon Rainforest and its vibrant culture.",
      difficulty: "easy"
    },
    {
      id: "geo_p2",
      question: "What is the capital city of Japan?",
      options: [
        "Beijing",
        "Seoul",
        "Tokyo",
        "Bangkok"
      ],
      correctAnswer: 2, // C - Tokyo
      explanation: "Tokyo is the capital city of Japan. It's one of the most populous cities in the world and a major global economic and cultural center.",
      difficulty: "easy"
    },
    {
      id: "geo_p3",
      question: "Which mountain range runs along the border between France and Spain?",
      options: [
        "The Alps",
        "The Pyrenees",
        "The Andes",
        "The Rockies"
      ],
      correctAnswer: 1, // B - The Pyrenees
      explanation: "The Pyrenees mountain range forms a natural border between France and Spain. It stretches for about 305 miles (491 km) from the Bay of Biscay to the Mediterranean Sea.",
      difficulty: "medium"
    },
    {
      id: "geo_p4",
      question: "Which of these countries is NOT in Europe?",
      options: [
        "Germany",
        "Portugal",
        "Thailand",
        "Sweden"
      ],
      correctAnswer: 2, // C - Thailand
      explanation: "Thailand is not in Europe - it's located in Southeast Asia. Germany, Portugal, and Sweden are all European countries.",
      difficulty: "medium"
    },
    {
      id: "geo_p5",
      question: "What is the largest river in the world by volume of water?",
      options: [
        "Nile River",
        "Mississippi River",
        "Yangtze River",
        "Amazon River"
      ],
      correctAnswer: 3, // D - Amazon River
      explanation: "The Amazon River is the largest river in the world by volume of water flow. It discharges more water than the next seven largest rivers combined! The Nile is longer, but the Amazon carries more water.",
      difficulty: "medium"
    },
    {
      id: "geo_p6",
      question: "Which of these cities is the capital of Australia?",
      options: [
        "Sydney",
        "Melbourne",
        "Canberra",
        "Brisbane"
      ],
      correctAnswer: 2, // C - Canberra
      explanation: "Canberra is the capital city of Australia. Many people think it's Sydney or Melbourne because they're larger and more well-known, but Canberra was specifically built to be the capital in the early 20th century.",
      difficulty: "medium"
    },
    {
      id: "geo_p7",
      question: "Which country has the most people?",
      options: [
        "United States",
        "India",
        "Russia",
        "Brazil"
      ],
      correctAnswer: 1, // B - India
      explanation: "As of 2023, India has surpassed China to become the most populous country in the world with approximately 1.4 billion people.",
      difficulty: "medium"
    },
    {
      id: "geo_p8",
      question: "Which of these is NOT one of the Great Lakes?",
      options: [
        "Lake Superior",
        "Lake Michigan",
        "Lake Ontario",
        "Lake Tahoe"
      ],
      correctAnswer: 3, // D - Lake Tahoe
      explanation: "Lake Tahoe is not one of the Great Lakes. The five Great Lakes are: Lake Superior, Lake Michigan, Lake Huron, Lake Erie, and Lake Ontario. They form the largest group of freshwater lakes on Earth!",
      difficulty: "medium"
    },
    {
      id: "geo_p9",
      question: "What is the capital city of Mexico?",
      options: [
        "Cancun",
        "Mexico City",
        "Guadalajara",
        "Monterrey"
      ],
      correctAnswer: 1, // B - Mexico City
      explanation: "Mexico City is the capital of Mexico. It's one of the largest cities in the world and was built on the site of the ancient Aztec city of Tenochtitlan.",
      difficulty: "medium"
    },
    {
      id: "geo_p10",
      question: "Which country is home to the Great Barrier Reef?",
      options: [
        "Brazil",
        "Thailand",
        "Australia",
        "South Africa"
      ],
      correctAnswer: 2, // C - Australia
      explanation: "The Great Barrier Reef is located off the northeastern coast of Australia. It's the world's largest coral reef system and can even be seen from space!",
      difficulty: "medium"
    },
    {
      id: "geo_p11",
      question: "Which of these countries is located in Africa?",
      options: [
        "Peru",
        "Vietnam",
        "Kenya",
        "Portugal"
      ],
      correctAnswer: 2, // C - Kenya
      explanation: "Kenya is located in East Africa. It's known for its diverse wildlife, national parks, and long-distance runners.",
      difficulty: "medium"
    },
    {
      id: "geo_p12",
      question: "What is the smallest continent by land area?",
      options: [
        "Europe",
        "Australia",
        "Antarctica",
        "South America"
      ],
      correctAnswer: 1, // B - Australia
      explanation: "Australia is the smallest continent by land area. It's unique in being both a continent and a country!",
      difficulty: "medium"
    },
    {
      id: "geo_p13",
      question: "Which of these countries is an island nation in the Caribbean?",
      options: [
        "Colombia",
        "Jamaica",
        "Portugal",
        "Morocco"
      ],
      correctAnswer: 1, // B - Jamaica
      explanation: "Jamaica is an island nation located in the Caribbean Sea. It's known for its beautiful beaches, reggae music, and being the birthplace of Bob Marley.",
      difficulty: "medium"
    },
    {
      id: "geo_p14",
      question: "What is the capital city of China?",
      options: [
        "Shanghai",
        "Hong Kong",
        "Beijing",
        "Taipei"
      ],
      correctAnswer: 2, // C - Beijing
      explanation: "Beijing is the capital city of China. It's one of the world's oldest cities and has been the political center of China for much of the past eight centuries.",
      difficulty: "medium"
    },
    {
      id: "geo_p15",
      question: "Which of these is the longest river in the United States?",
      options: [
        "Colorado River",
        "Mississippi River",
        "Rio Grande",
        "Yukon River"
      ],
      correctAnswer: 1, // B - Mississippi River
      explanation: "The Mississippi River is the longest river in the United States, flowing about 2,340 miles (3,766 km) from its source at Lake Itasca in Minnesota to the Gulf of Mexico.",
      difficulty: "medium"
    }
  ],
  
  teen: [
    {
      id: "geo_t1",
      question: "Which of these countries does NOT border China?",
      options: [
        "Russia",
        "India",
        "Thailand",
        "Kazakhstan"
      ],
      correctAnswer: 2, // C - Thailand
      explanation: "Thailand does not share a border with China. China shares borders with 14 countries: Russia, Mongolia, North Korea, Vietnam, Laos, Myanmar, India, Bhutan, Nepal, Pakistan, Afghanistan, Tajikistan, Kyrgyzstan, and Kazakhstan.",
      difficulty: "hard"
    },
    {
      id: "geo_t2",
      question: "What is the capital city of Brazil?",
      options: [
        "Rio de Janeiro",
        "São Paulo",
        "Brasília",
        "Salvador"
      ],
      correctAnswer: 2, // C - Brasília
      explanation: "Brasília is the capital city of Brazil. It was purpose-built to be the capital in the late 1950s and was officially inaugurated in 1960, replacing Rio de Janeiro as the capital.",
      difficulty: "medium"
    },
    {
      id: "geo_t3",
      question: "Which of these mountain ranges is located in Asia?",
      options: [
        "The Andes",
        "The Alps",
        "The Himalayas",
        "The Appalachians"
      ],
      correctAnswer: 2, // C - The Himalayas
      explanation: "The Himalayas are located in Asia, spanning the countries of India, Nepal, Bhutan, China (Tibet), and Pakistan. They contain nine of the world's ten highest peaks, including Mount Everest.",
      difficulty: "medium"
    },
    {
      id: "geo_t4",
      question: "Which of these countries is landlocked (has no coastline)?",
      options: [
        "Vietnam",
        "Bolivia",
        "Italy",
        "Japan"
      ],
      correctAnswer: 1, // B - Bolivia
      explanation: "Bolivia is a landlocked country in South America. It lost its coastal territory to Chile in the War of the Pacific (1879-1884) and has been landlocked ever since.",
      difficulty: "hard"
    },
    {
      id: "geo_t5",
      question: "What is the largest desert in the world?",
      options: [
        "Sahara Desert",
        "Arabian Desert",
        "Gobi Desert",
        "Antarctic Desert"
      ],
      correctAnswer: 3, // D - Antarctic Desert
      explanation: "The Antarctic Desert is the largest desert in the world. Many people don't realize that Antarctica is classified as a desert because it receives very little precipitation (less than 200mm per year). The Sahara is the largest hot desert.",
      difficulty: "hard"
    },
    {
      id: "geo_t6",
      question: "Which of these cities is NOT a national capital?",
      options: [
        "Cairo",
        "Sydney",
        "Bangkok",
        "Vienna"
      ],
      correctAnswer: 1, // B - Sydney
      explanation: "Sydney is not a national capital. Cairo is the capital of Egypt, Bangkok is the capital of Thailand, and Vienna is the capital of Austria. The capital of Australia is Canberra, not Sydney.",
      difficulty: "medium"
    },
    {
      id: "geo_t7",
      question: "Which strait separates Asia from North America?",
      options: [
        "Strait of Gibraltar",
        "Strait of Malacca",
        "Bering Strait",
        "Strait of Hormuz"
      ],
      correctAnswer: 2, // C - Bering Strait
      explanation: "The Bering Strait separates Asia (Russia) from North America (Alaska, USA). At its narrowest point, the strait is only about 53 miles (85 km) wide.",
      difficulty: "hard"
    },
    {
      id: "geo_t8",
      question: "Which of these countries is located in the Southern Hemisphere?",
      options: [
        "Mexico",
        "Egypt",
        "India",
        "New Zealand"
      ],
      correctAnswer: 3, // D - New Zealand
      explanation: "New Zealand is located in the Southern Hemisphere. Mexico, Egypt, and India are all located in the Northern Hemisphere.",
      difficulty: "medium"
    },
    {
      id: "geo_t9",
      question: "What is the capital city of South Africa?",
      options: [
        "Cape Town",
        "Johannesburg",
        "Pretoria",
        "All of these are capitals"
      ],
      correctAnswer: 3, // D - All of these are capitals
      explanation: "South Africa has three capital cities: Pretoria (administrative), Cape Town (legislative), and Bloemfontein (judicial). Johannesburg is not officially a capital but is the largest city and economic center.",
      difficulty: "hard"
    },
    {
      id: "geo_t10",
      question: "Which of these countries is NOT a member of the European Union?",
      options: [
        "Sweden",
        "Portugal",
        "Switzerland",
        "Belgium"
      ],
      correctAnswer: 2, // C - Switzerland
      explanation: "Switzerland is not a member of the European Union. It maintains its independence and has its own agreements with the EU, but is not a member state.",
      difficulty: "hard"
    },
    {
      id: "geo_t11",
      question: "Which of these cities is located at the highest elevation?",
      options: [
        "Mexico City",
        "Denver",
        "Kathmandu",
        "La Paz"
      ],
      correctAnswer: 3, // D - La Paz
      explanation: "La Paz, Bolivia is located at the highest elevation among these cities, at approximately 11,942 feet (3,640 meters) above sea level. It's the highest administrative capital city in the world.",
      difficulty: "hard"
    },
    {
      id: "geo_t12",
      question: "Which of these countries has the longest coastline?",
      options: [
        "Russia",
        "Australia",
        "United States",
        "Canada"
      ],
      correctAnswer: 3, // D - Canada
      explanation: "Canada has the longest coastline in the world, measuring about 151,019 miles (243,042 km). This is due to its many islands and the irregular shape of its coastline.",
      difficulty: "hard"
    },
    {
      id: "geo_t13",
      question: "Which of these is the official language of Brazil?",
      options: [
        "Spanish",
        "Portuguese",
        "French",
        "English"
      ],
      correctAnswer: 1, // B - Portuguese
      explanation: "Portuguese is the official language of Brazil. This is because Brazil was colonized by Portugal in the 16th century, unlike most other South American countries which were colonized by Spain.",
      difficulty: "medium"
    },
    {
      id: "geo_t14",
      question: "Which of these countries is located on the equator?",
      options: [
        "Colombia",
        "Peru",
        "Venezuela",
        "Ecuador"
      ],
      correctAnswer: 3, // D - Ecuador
      explanation: "Ecuador is located on the equator - in fact, its name 'Ecuador' is Spanish for 'equator'! The country was named for its geographical position.",
      difficulty: "medium"
    },
    {
      id: "geo_t15",
      question: "Which of these bodies of water is NOT a sea?",
      options: [
        "Caspian Sea",
        "Dead Sea",
        "Red Sea",
        "Sargasso Sea"
      ],
      correctAnswer: 3, // D - Sargasso Sea
      explanation: "The Sargasso Sea is not technically a sea - it's a region of the North Atlantic Ocean that is bounded by ocean currents. The Caspian Sea is actually a lake, despite its name, while the Dead Sea is a salt lake. The Red Sea is a true sea.",
      difficulty: "hard"
    }
  ],
  
  adult: [
    {
      id: "geo_a1",
      question: "Which of these countries is NOT a member of the United Nations?",
      options: [
        "Switzerland",
        "Vatican City",
        "North Korea",
        "Cuba"
      ],
      correctAnswer: 1, // B - Vatican City
      explanation: "Vatican City is not a member of the United Nations. It has permanent observer status but is not a full member. Switzerland joined the UN in 2002, while North Korea and Cuba are both members.",
      difficulty: "hard"
    },
    {
      id: "geo_a2",
      question: "Which of these cities is located at the confluence of the Blue Nile and White Nile rivers?",
      options: [
        "Cairo",
        "Khartoum",
        "Addis Ababa",
        "Nairobi"
      ],
      correctAnswer: 1, // B - Khartoum
      explanation: "Khartoum, the capital of Sudan, is located at the confluence of the Blue Nile and White Nile rivers. This strategic location has made it an important city throughout history.",
      difficulty: "hard"
    },
    {
      id: "geo_a3",
      question: "Which of these countries is completely surrounded by another country?",
      options: [
        "Monaco",
        "Lesotho",
        "Luxembourg",
        "Andorra"
      ],
      correctAnswer: 1, // B - Lesotho
      explanation: "Lesotho is completely surrounded by South Africa, making it an 'enclave' state. Monaco borders France and the Mediterranean Sea, Luxembourg borders multiple countries, and Andorra is between Spain and France.",
      difficulty: "hard"
    },
    {
      id: "geo_a4",
      question: "Which of these mountain peaks is NOT located in Asia?",
      options: [
        "K2",
        "Kangchenjunga",
        "Aconcagua",
        "Lhotse"
      ],
      correctAnswer: 2, // C - Aconcagua
      explanation: "Aconcagua is not located in Asia - it's in South America (Argentina) and is the highest mountain outside of Asia. K2, Kangchenjunga, and Lhotse are all in the Himalayan and Karakoram ranges in Asia.",
      difficulty: "hard"
    },
    {
      id: "geo_a5",
      question: "Which of these straits connects the Mediterranean Sea to the Atlantic Ocean?",
      options: [
        "Strait of Gibraltar",
        "Strait of Hormuz",
        "Strait of Malacca",
        "Bosporus Strait"
      ],
      correctAnswer: 0, // A - Strait of Gibraltar
      explanation: "The Strait of Gibraltar connects the Mediterranean Sea to the Atlantic Ocean, separating Europe (Spain) from Africa (Morocco). It's only about 8.9 miles (14.3 km) wide at its narrowest point.",
      difficulty: "hard"
    },
    {
      id: "geo_a6",
      question: "Which of these countries has territory in both Europe and Asia?",
      options: [
        "Greece",
        "Egypt",
        "Turkey",
        "Iran"
      ],
      correctAnswer: 2, // C - Turkey
      explanation: "Turkey has territory in both Europe and Asia. The Bosporus Strait in Istanbul divides the country between the two continents. About 97% of Turkey's land area is in Asia, with the remaining 3% in Europe.",
      difficulty: "hard"
    },
    {
      id: "geo_a7",
      question: "Which of these cities is NOT located on the Danube River?",
      options: [
        "Vienna",
        "Budapest",
        "Prague",
        "Belgrade"
      ],
      correctAnswer: 2, // C - Prague
      explanation: "Prague is not located on the Danube River - it's on the Vltava River. Vienna (Austria), Budapest (Hungary), and Belgrade (Serbia) are all located on the Danube, which is Europe's second-longest river.",
      difficulty: "hard"
    },
    {
      id: "geo_a8",
      question: "Which of these countries has the highest population density?",
      options: [
        "Netherlands",
        "Japan",
        "Bangladesh",
        "India"
      ],
      correctAnswer: 2, // C - Bangladesh
      explanation: "Bangladesh has the highest population density among these countries, with approximately 1,265 people per square kilometer. It's one of the most densely populated large countries in the world.",
      difficulty: "hard"
    },
    {
      id: "geo_a9",
      question: "Which of these African countries was NEVER colonized by European powers?",
      options: [
        "South Africa",
        "Ethiopia",
        "Kenya",
        "Nigeria"
      ],
      correctAnswer: 1, // B - Ethiopia
      explanation: "Ethiopia was never successfully colonized by European powers, although Italy briefly occupied it from 1936-1941. It's one of the oldest independent countries in Africa and the world.",
      difficulty: "hard"
    },
    {
      id: "geo_a10",
      question: "Which of these cities is located at the southernmost latitude?",
      options: [
        "Cape Town",
        "Sydney",
        "Buenos Aires",
        "Wellington"
      ],
      correctAnswer: 0, // A - Cape Town
      explanation: "Cape Town, South Africa is located at the southernmost latitude among these cities, at approximately 33.9°S. Wellington is at about 41.3°S but is further east, Sydney is at 33.9°S, and Buenos Aires is at 34.6°S.",
      difficulty: "hard"
    },
    {
      id: "geo_a11",
      question: "Which of these countries does NOT have a federal system of government?",
      options: [
        "Germany",
        "France",
        "Brazil",
        "Australia"
      ],
      correctAnswer: 1, // B - France
      explanation: "France does not have a federal system of government - it has a unitary system with power centralized in the national government. Germany, Brazil, and Australia all have federal systems with power shared between national and state/provincial governments.",
      difficulty: "hard"
    },
    {
      id: "geo_a12",
      question: "Which of these islands is NOT part of Indonesia?",
      options: [
        "Sumatra",
        "Java",
        "Borneo",
        "Taiwan"
      ],
      correctAnswer: 3, // D - Taiwan
      explanation: "Taiwan is not part of Indonesia - it's an island off the coast of mainland China with its own government. Sumatra, Java, and parts of Borneo (Kalimantan) are all major islands that are part of Indonesia.",
      difficulty: "hard"
    },
    {
      id: "geo_a13",
      question: "Which of these countries has a non-rectangular flag?",
      options: [
        "Japan",
        "Nepal",
        "South Africa",
        "Brazil"
      ],
      correctAnswer: 1, // B - Nepal
      explanation: "Nepal has the only non-rectangular national flag in the world. It consists of two triangular pennants stacked on top of each other, representing the Himalayan Mountains and the former royal house.",
      difficulty: "hard"
    },
    {
      id: "geo_a14",
      question: "Which of these cities is NOT a national capital but is the largest city in its country?",
      options: [
        "Toronto",
        "Sydney",
        "Rio de Janeiro",
        "All of these fit the description"
      ],
      correctAnswer: 3, // D - All of these fit the description
      explanation: "All of these cities fit the description: Toronto is the largest city in Canada (not the capital), Sydney is the largest city in Australia (not the capital), and Rio de Janeiro is the largest city in Brazil (not the capital).",
      difficulty: "hard"
    },
    {
      id: "geo_a15",
      question: "Which of these time zones is the furthest east?",
      options: [
        "Greenwich Mean Time (GMT)",
        "Eastern Standard Time (EST)",
        "Japan Standard Time (JST)",
        "New Zealand Standard Time (NZST)"
      ],
      correctAnswer: 3, // D - New Zealand Standard Time (NZST)
      explanation: "New Zealand Standard Time (NZST) is the furthest east among these time zones, at GMT+12. Japan Standard Time is GMT+9, Eastern Standard Time is GMT-5, and Greenwich Mean Time is GMT+0.",
      difficulty: "hard"
    }
  ]
};
