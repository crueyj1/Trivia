// Score Display Bug Fix for Oh my Skibity Sigma
// This file fixes the issue where scores show as "Zero to Zero" after a round

// Update the renderRoundResults function to properly display scores
function renderRoundResults() {
  if (gameState.gameType !== GAME_TYPE.MULTIPLAYER) {
    return;
  }
  
  const roundResults = document.createElement('div');
  roundResults.className = 'round-results';
  
  // Find the round winner
  let highestScore = -1;
  let winnerIndex = -1;
  
  gameState.players.forEach((player, index) => {
    if (player.roundScore > highestScore) {
      highestScore = player.roundScore;
      winnerIndex = index;
    }
  });
  
  const roundWinner = winnerIndex >= 0 ? gameState.players[winnerIndex] : null;
  
  // Create round results content
  roundResults.innerHTML = `
    <h2>Round ${gameState.currentRound - 1} Results</h2>
    
    <div class="round-winner">
      <h3>${roundWinner ? `${roundWinner.name} wins this round!` : 'This round ended in a tie!'}</h3>
    </div>
    
    <div class="player-round-results">
      ${gameState.players.map(player => `
        <div class="player-round-result ${player.id === (roundWinner ? roundWinner.id : -1) ? 'winner' : ''}">
          <div class="player-name">${player.name}</div>
          <div class="player-round-score">Round Score: ${player.roundScore}</div>
          <div class="player-total-score">Total Score: ${player.score}</div>
        </div>
      `).join('')}
    </div>
    
    <div class="series-status">
      <h3>Series Status:</h3>
      ${gameState.players.map(player => `
        <div class="player-series-status">
          <span class="player-name">${player.name}:</span>
          <span class="player-wins">${player.seriesWins} ${player.seriesWins === 1 ? 'win' : 'wins'}</span>
        </div>
      `).join('')}
    </div>
    
    <div class="round-buttons">
      <button class="btn next-round-btn">Start Round ${gameState.currentRound}</button>
    </div>
  `;
  
  // Add event listener for next round button
  roundResults.querySelector('.next-round-btn').addEventListener('click', function() {
    getNextQuestion();
    renderGameState();
  });
  
  gameContainer.appendChild(roundResults);
}

// Update the updateScores function to properly track round scores
function updateScores(isCorrect, pointsAwarded) {
  if (gameState.gameType === GAME_TYPE.MULTIPLAYER) {
    const currentPlayer = gameState.players[gameState.currentPlayerIndex];
    
    if (isCorrect) {
      currentPlayer.score += pointsAwarded;
      currentPlayer.roundScore += pointsAwarded; // Track round score separately
    }
    
    currentPlayer.questionsAnswered++;
    
    if (isCorrect) {
      currentPlayer.correctAnswers++;
    }
  } else {
    if (isCorrect) {
      gameState.score += pointsAwarded;
    }
    
    gameState.questionsAnswered++;
    
    if (isCorrect) {
      gameState.correctAnswers++;
    }
  }
}

// Update the setupMultiplayerGame function to initialize roundScore
function setupMultiplayerGame(playerData) {
  gameState.gameType = GAME_TYPE.MULTIPLAYER;
  gameState.players = [];
  gameState.currentPlayerIndex = 0;
  gameState.currentRound = 1;
  gameState.roundWinners = [];
  gameState.questionsPerRound = 5; // Updated to 5 questions per round
  gameState.questionCount = 0;
  gameState.gameStatus = GAME_STATUS.PLAYING;
  
  // Create player objects
  playerData.forEach((player, index) => {
    gameState.players.push({
      id: index,
      name: player.name,
      age: player.age,
      score: 0,
      roundScore: 0, // Initialize round score
      seriesWins: 0,
      questionsAnswered: 0,
      correctAnswers: 0,
      isActive: index === 0
    });
  });
}

// Update the endRound function to reset round scores and determine round winner
function endRound() {
  // Find player with highest score this round
  let highestScore = -1;
  let winnerIndex = -1;
  
  gameState.players.forEach((player, index) => {
    if (player.roundScore > highestScore) {
      highestScore = player.roundScore;
      winnerIndex = index;
    }
  });
  
  // If there's a winner, increment their series wins
  if (winnerIndex >= 0) {
    gameState.players[winnerIndex].seriesWins++;
    gameState.roundWinners.push(gameState.players[winnerIndex].id);
  } else {
    // Push -1 to indicate a tie
    gameState.roundWinners.push(-1);
  }
  
  // Reset for next round
  gameState.currentRound++;
  gameState.questionCount = 0;
  gameState.currentPlayerIndex = 0;
  
  // Reset round scores for all players
  gameState.players.forEach(player => {
    player.roundScore = 0;
    player.isActive = false;
  });
  
  // Set first player as active
  if (gameState.players.length > 0) {
    gameState.players[0].isActive = true;
  }
  
  // Check if series is over (best of 3)
  const maxWins = Math.ceil(3 / 2); // 2 wins needed for best of 3
  const seriesOver = gameState.players.some(player => player.seriesWins >= maxWins) || 
                    gameState.currentRound > 3;
  
  if (seriesOver) {
    gameState.gameStatus = GAME_STATUS.SERIES_END;
  } else {
    gameState.gameStatus = GAME_STATUS.ROUND_END;
  }
}
