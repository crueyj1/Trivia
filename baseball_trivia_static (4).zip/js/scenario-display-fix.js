// Enhanced UI Controller for Oh my Skibity Sigma - Bug Fix for Scenario Display
// This file updates the renderGameScreen function to properly display scenarios

// Update the renderGameScreen function to ensure scenarios are visible
function renderGameScreen() {
  if (!gameState.currentQuestion) {
    console.error('No current question available');
    return;
  }
  
  const gameScreen = document.createElement('div');
  gameScreen.className = 'game-screen';
  
  // Create header with game info
  const gameHeader = document.createElement('div');
  gameHeader.className = 'game-header';
  
  if (gameState.gameType === GAME_TYPE.MULTIPLAYER) {
    // Multiplayer header
    const currentPlayer = gameState.players[gameState.currentPlayerIndex];
    
    gameHeader.innerHTML = `
      <div class="game-info">
        <div class="round-info">Round ${gameState.currentRound}/3</div>
        <div class="question-counter">Question ${gameState.questionCount + 1}/${gameState.questionsPerRound}</div>
      </div>
      
      <div class="player-info">
        <div class="current-player">
          <span class="player-label">Current Player:</span>
          <span class="player-name">${currentPlayer.name}</span>
          <span class="player-age">(Age: ${currentPlayer.age})</span>
        </div>
      </div>
      
      <div class="scoreboard">
        ${gameState.players.map(player => `
          <div class="player-score ${player.isActive ? 'active' : ''}">
            <span class="score-name">${player.name}</span>
            <span class="score-value">${player.score}</span>
          </div>
        `).join('')}
      </div>
    `;
  } else {
    // Single player header
    gameHeader.innerHTML = `
      <div class="game-info">
        <div class="category-info">${getCategoryName(gameState.categoryType)}</div>
        <div class="mode-info">${gameState.gameMode === GAME_MODE.KID ? 'Kid Mode' : 'Adult Mode'}</div>
      </div>
      
      <div class="score-display">
        <span class="score-label">Score:</span>
        <span class="score-value">${gameState.score}</span>
      </div>
    `;
  }
  
  // Create question display
  const questionDisplay = document.createElement('div');
  questionDisplay.className = 'question-display';
  
  // Get difficulty class
  const difficultyClass = gameState.currentQuestion.difficulty.toLowerCase();
  
  // Check if there's a scenario property and display it
  const hasScenario = gameState.currentQuestion.scenario && gameState.currentQuestion.scenario.trim() !== '';
  
  questionDisplay.innerHTML = `
    <div class="difficulty-badge ${difficultyClass}">${gameState.currentQuestion.difficulty}</div>
    ${hasScenario ? `<div class="scenario-text">${gameState.currentQuestion.scenario}</div>` : ''}
    <div class="question-text">${gameState.currentQuestion.question}</div>
  `;
  
  // Create answer options
  const answerOptions = document.createElement('div');
  answerOptions.className = 'answer-options';
  
  if (gameState.currentQuestion.options) {
    // Multiple choice question
    gameState.currentQuestion.options.forEach((option, index) => {
      const letter = String.fromCharCode(65 + index); // A, B, C, D
      
      const optionButton = document.createElement('button');
      optionButton.className = 'answer-option';
      optionButton.dataset.answer = letter;
      
      optionButton.innerHTML = `
        <span class="option-letter">${letter}</span>
        <span class="option-text">${option}</span>
      `;
      
      optionButton.addEventListener('click', function() {
        submitAnswer(letter);
      });
      
      answerOptions.appendChild(optionButton);
    });
  }
  
  // Assemble the game screen
  gameScreen.appendChild(gameHeader);
  gameScreen.appendChild(questionDisplay);
  gameScreen.appendChild(answerOptions);
  
  gameContainer.appendChild(gameScreen);
}

// Add CSS for scenario display
document.addEventListener('DOMContentLoaded', function() {
  const styleElement = document.createElement('style');
  styleElement.textContent = `
    .scenario-text {
      background-color: #f0f4ff;
      padding: 15px;
      margin-bottom: 20px;
      border-left: 4px solid var(--primary-color);
      border-radius: 4px;
      font-style: italic;
      line-height: 1.6;
    }
    
    @media (max-width: 768px) {
      .scenario-text {
        padding: 10px;
        margin-bottom: 15px;
      }
    }
  `;
  document.head.appendChild(styleElement);
});
