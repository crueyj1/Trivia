// User profile inputs and age-based difficulty scaling implementation

// Add new constants for age groups
const AGE_GROUP = {
  CHILD: 'child',     // Ages 5-10
  PRETEEN: 'preteen', // Ages 11-13
  TEEN: 'teen',       // Ages 14-17
  ADULT: 'adult'      // Ages 18+
};

// Extend the player object structure to include age and derived age group
function createPlayer(name, age, id) {
  return {
    id: id || 1,
    name: name || 'Player',
    age: age || 0,
    ageGroup: getAgeGroup(age),
    score: 0,
    seriesWins: 0,
    isActive: false
  };
}

// Function to determine age group based on age
function getAgeGroup(age) {
  if (!age || typeof age !== 'number') return AGE_GROUP.PRETEEN; // Default to preteen (11-13)
  
  if (age < 11) return AGE_GROUP.CHILD;
  if (age < 14) return AGE_GROUP.PRETEEN;
  if (age < 18) return AGE_GROUP.TEEN;
  return AGE_GROUP.ADULT;
}

// Modify the setupMultiplayerGame function to include age
function setupMultiplayerGame(playerData) {
  if (!Array.isArray(playerData) || playerData.length < 2 || playerData.length > 4) {
    console.error('Invalid player data. Need 2-4 players.');
    return gameState;
  }
  
  // Create player objects with name and age
  gameState.players = playerData.map((player, index) => ({
    id: index + 1,
    name: player.name || `Player ${index + 1}`,
    age: player.age || 0,
    ageGroup: getAgeGroup(player.age),
    score: 0,
    seriesWins: 0,
    isActive: index === 0 // First player starts
  }));
  
  gameState.currentPlayerIndex = 0;
  gameState.currentRound = 1;
  gameState.questionCount = 0;
  gameState.roundWinners = [];
  
  // Load questions for the round
  loadQuestionsForRound();
  
  return gameState;
}

// Modify the loadQuestionsForRound function to consider age
function loadQuestionsForRound() {
  // Get questions based on current mode, category, and player age
  let allQuestions = [];
  
  // Get the current player's age group
  const currentPlayer = gameState.players[gameState.currentPlayerIndex];
  const playerAgeGroup = currentPlayer ? currentPlayer.ageGroup : AGE_GROUP.PRETEEN;
  
  // Select questions based on category and age-appropriate difficulty
  switch (gameState.categoryType) {
    case CATEGORY_TYPE.FIELDING:
      allQuestions = getFieldingQuestionsByAgeGroup(playerAgeGroup);
      break;
    case CATEGORY_TYPE.CURRENT:
      allQuestions = getCurrentBaseballQuestionsByAgeGroup(playerAgeGroup);
      break;
    case CATEGORY_TYPE.BASKETBALL:
      allQuestions = getBasketballQuestionsByAgeGroup(playerAgeGroup);
      break;
    case CATEGORY_TYPE.GEOGRAPHY:
      allQuestions = getGeographyQuestionsByAgeGroup(playerAgeGroup);
      break;
    case CATEGORY_TYPE.MATHEMATICS:
      allQuestions = getMathQuestionsByAgeGroup(playerAgeGroup);
      break;
    default:
      // Fallback to fielding questions
      allQuestions = getFieldingQuestionsByAgeGroup(playerAgeGroup);
  }
  
  // Shuffle questions and select the required number
  shuffleArray(allQuestions);
  gameState.availableQuestions = allQuestions.slice(0, gameState.questionsPerRound);
  
  return gameState;
}

// Helper functions to get age-appropriate questions for each category
function getFieldingQuestionsByAgeGroup(ageGroup) {
  switch (ageGroup) {
    case AGE_GROUP.CHILD:
      return scenarios.easy;
    case AGE_GROUP.PRETEEN:
      return [...scenarios.easy, ...scenarios.medium.slice(0, 3)];
    case AGE_GROUP.TEEN:
      return [...scenarios.easy.slice(0, 2), ...scenarios.medium, ...scenarios.hard.slice(0, 2)];
    case AGE_GROUP.ADULT:
      return [...scenarios.medium, ...scenarios.hard];
    default:
      return scenarios.medium;
  }
}

function getCurrentBaseballQuestionsByAgeGroup(ageGroup) {
  switch (ageGroup) {
    case AGE_GROUP.CHILD:
    case AGE_GROUP.PRETEEN:
      return currentBaseballTrivia.kid;
    case AGE_GROUP.TEEN:
      // Mix of kid and adult questions for teens
      return [
        ...currentBaseballTrivia.kid.slice(0, 8),
        ...currentBaseballTrivia.adult.slice(0, 7)
      ];
    case AGE_GROUP.ADULT:
      return currentBaseballTrivia.adult;
    default:
      return currentBaseballTrivia.kid;
  }
}

// Placeholder functions for the new categories
// These will be implemented fully when we create the content
function getBasketballQuestionsByAgeGroup(ageGroup) {
  // Will be replaced with actual basketball questions
  return [];
}

function getGeographyQuestionsByAgeGroup(ageGroup) {
  // Will be replaced with actual geography questions
  return [];
}

function getMathQuestionsByAgeGroup(ageGroup) {
  // Will be replaced with actual math questions
  return [];
}

// Update the getNextQuestion function to handle age-specific questions
function getNextQuestion() {
  // For multiplayer, check if we need to move to next round
  if (gameState.gameType === GAME_TYPE.MULTIPLAYER) {
    // If all questions for this round have been answered
    if (gameState.questionCount >= gameState.questionsPerRound) {
      return endRound();
    }
    
    // If we're moving to a new player, we might need to reload questions
    // based on the new player's age
    const currentPlayer = gameState.players[gameState.currentPlayerIndex];
    if (currentPlayer && gameState.lastPlayerAgeGroup !== currentPlayer.ageGroup) {
      // Store the current player's age group for comparison
      gameState.lastPlayerAgeGroup = currentPlayer.ageGroup;
      // Reload questions for this player's age group
      loadQuestionsForRound();
    }
  }
  
  // Get the current question
  const questionIndex = gameState.gameType === GAME_TYPE.MULTIPLAYER ? 
    gameState.questionCount : 
    0; // In single player, always take the first question
  
  if (questionIndex >= gameState.availableQuestions.length) {
    // No more questions available
    gameState.gameStatus = gameState.gameType === GAME_TYPE.MULTIPLAYER ? 
      GAME_STATUS.ROUND_END : 
      GAME_STATUS.FINISHED;
    return gameState;
  }
  
  // Set the current question
  gameState.currentQuestion = gameState.availableQuestions[questionIndex];
  gameState.gameStatus = GAME_STATUS.PLAYING;
  gameState.answerResult = null;
  
  return gameState;
}
